// 412 Film: the window's page.  Talks to the engine on this Mac only.
'use strict';
const $=id=>document.getElementById(id);
const native=m=>{ try{ window.webkit.messageHandlers.app.postMessage(m); return true; }catch(e){ return false; } };
const hasNative=!!(window.webkit&&window.webkit.messageHandlers&&window.webkit.messageHandlers.app);
const post=async(p,b)=>{ const r=await fetch(p,{method:'POST',body:JSON.stringify(b===undefined?{}:b)}); return r.json(); };
const U=encodeURIComponent;                   // every picture or scan name that goes into an address

let resumed=0, startBad=false;
let flagged=new Set();                        // the pictures to check, as they were when this folder was opened in this window
let st=null, D=null, Dout=null, pics=[], fixes={}, order=[], cur=0, sel=new Set(), clip=false, ctx=false, redFirst=true, clipb=null, saveT=null, ver=Date.now();
let wantRun=-1, wantSeen=false;               // (the export a wanted view waits for: begun after this many runs; seen running)
let hist={undo:[],redo:[]}, baseStr=null, tagNow=null, heldTag=null, tagN=0, exportedC={}, pair=false, view='rolls', wantView=null, loadedKey='', lastCP=0, toldId=0, startNote='', asideSel=null, fails=0; const cache={};
const img=new Image(), cv=$('cv'), mid=document.createElement('canvas');
const NOFIX={turn:0,at:-1,density:0,contrast:0,skip:0,mirror:0,ok:0,crop:[0,0,0,0],tilt:0,diptych:0,closed:0,keep:0,sat:0,warm:0,tint:0};
// a roll's settings are kept under one of its scans' names (the engine says which), so they stay with the roll
const rk=n=>(D&&D.rolls&&D.rolls[n-1]&&D.rolls[n-1].key)||('/roll '+n);
const rollMem=n=>{ const r=D&&D.rolls&&D.rolls[n-1]; return r&&Array.isArray(r.members)?{members:r.members}:{}; };
const rollFx=n=>fixes[rk(n)]?{...fixes[rk(n)],...rollMem(n)}:{mode:null,note:'',film:null,sat:0,warm:0,tint:0,...rollMem(n)};
// which way up a picture is before his own turns: the automatic turn, or the one it had when he first turned or approved it
const autoT=(p,f)=>f&&f.at>=0?f.at:p.auto_turns;
const pin=(f,p)=>{ if(!(f.at>=0)) f.at=p.auto_turns; };
const get=id=>fixes[id]||NOFIX;
const fx=id=>{ if(!fixes[id]) fixes[id]={...NOFIX,crop:[0,0,0,0]}; if(!fixes[id].crop) fixes[id].crop=[0,0,0,0]; return fixes[id]; };
const r2=v=>Math.round(v*100)/100;
const short=s=>D.prefix&&s.startsWith(D.prefix)?s.slice(D.prefix.length):s;
const dipAll=()=>(fixes['/options']||[]).includes('diptych');
// a diptych is made for this scan: its own say (1 yes, -1 "not for this scan" against the folder option), else the folder option
const dipOn=sf=>sf.diptych>0||(!sf.diptych&&dipAll());
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const base=p=>p.replace(/\/+$/,'').split('/').pop();
// A folder's name as the window shows it: with its parent's when the name alone says little ("1", "Scans", "DNG"):
// "2026.11.10 Film Scan › 1"
const GENERIC=/^(\d+|.{1,2}|scans?|dng|nef|raw|raws|film|films|negatives?|roll\s*\d*|untitled folder( \d+)?|new folder( \d+)?)$/i;
function folderName(p){ const parts=String(p||'').replace(/\/+$/,'').split('/').filter(Boolean), b=parts.pop()||''; return GENERIC.test(b.trim())&&parts.length?parts.pop()+' › '+b:b; }
// "2026-11-14 16:44" said as a person would: Today 16:44, Yesterday 09:10, Thu 12 Nov, 12 Nov 2025
function friendlyWhen(w){ const m=/^(\d{4})-(\d\d)-(\d\d) (\d\d:\d\d)$/.exec(String(w||'')); if(!m) return String(w||'');
  const d=new Date(+m[1],+m[2]-1,+m[3]), now=new Date(), t0=new Date(now.getFullYear(),now.getMonth(),now.getDate()), days=Math.round((t0-d)/864e5);
  const mon=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()], wd=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][d.getDay()];
  return days===0?'Today '+m[4]:days===1?'Yesterday '+m[4]:days>1&&days<7?wd+' '+d.getDate()+' '+mon:d.getDate()+' '+mon+(d.getFullYear()===now.getFullYear()?'':' '+d.getFullYear()); }
// where the pictures are, short: "colour2 › Positives" (the output folder inside the scans' folder), else its last two folders
function where(path){ path=String(path||st.out||'').replace(/\/+$/,''); const f=String(st.folder||'').replace(/\/+$/,'');
  if(f&&path.startsWith(f+'/')) return [folderName(f)].concat(path.slice(f.length+1).split('/')).join(' › ');
  return path.split('/').filter(Boolean).slice(-2).join(' › '); }
const onMain=()=>$('s-main').classList.contains('on');

// ------------------------------------------------------------------ screens

function screen(id){ ['s-start','s-work','s-dng','s-main'].forEach(s=>$(s).classList.toggle('on',s===id)); reportDrag(); }
// Leaving Rolls for the pictures (the tabs, Space, a click in a strip): while a roll's type or film has been changed
// since the export, the pictures on screen are not the pictures that change makes (some go, others come), so it
// exports first, as Review the pictures does; the view it was asked for opens when the export is done.
function goView(v){
  if(view==='rolls'&&v!=='rolls'&&D&&rollTypeChanged()){ wantView=v; wantRun=st.runs; wantSeen=false; exportAll(); return; }
  setView(v);
}
function setView(v){
  view=v; ['rolls','grid','single'].forEach(x=>$('v-'+x).classList.toggle('on',x===v));
  document.querySelectorAll('#tabs button').forEach(b=>b.classList.toggle('on',b.dataset.v===v));
  // (with no pictures at all there is nothing to put in order or to reset: those buttons go; engine 66 #9)
  $('order').style.display=v==='rolls'||!pics.length?'none':''; $('breset').style.display=pics.length?'':'none';
  if(v==='rolls') drawRolls();
  if(v==='grid'){ drawGrid(); const c=$('t'+cur); if(c) c.scrollIntoView({block:'nearest'}); }
  if(v==='single') show(cur);
  info(); reportDrag();
}
// (one look at the engine at a time, in order: two at once could both load the folder, and the second would put its
//  first-opening line over what the engine had to say, e.g. "Stopped.")
let pollQ=Promise.resolve();
function poll(){ pollQ=pollQ.then(pollOnce,pollOnce); return pollQ; }
async function pollOnce(){
  // (engine 67: a look that fails, or hangs for 20 s, is tried again; before, one failed look stopped the polling for good and the
  //  window sat still, mid-export, with nothing to say so)
  try{ const ac=new AbortController(), to=setTimeout(()=>ac.abort(),20000);
       try{ const r=await fetch('/state',{signal:ac.signal}); if(!r.ok) throw 0; st=await r.json(); } finally{ clearTimeout(to); }
       fails=0; $('down').style.display='none'; }
  catch(e){ if(++fails>=3) engineDown(); clearTimeout(poll.t); poll.t=setTimeout(poll,1500); return; }
  // (the engine answers; if this folder's pictures cannot be read just now, that is said as what it is, and tried again)
  try{ await apply(); dataFails=0; }catch(e){ $('busy').style.display='none'; if(++dataFails===3) msg('The pictures of this folder could not be read just now. Trying again; if this stays, press Export All.',1); }
  clearTimeout(poll.t); poll.t=setTimeout(poll, st&&st.phase==='working'?350:1500);
}
function engineDown(){ $('down').style.display='flex'; }   // said in the window; the app starts the engine again and puts this folder back

// what the app itself calls
window.appRefresh=()=>poll();
window.appDragging=on=>{ $('dragveil').firstElementChild.textContent=exporting()?'Exporting: open another folder when it is done':'Drop to open'; $('dragveil').style.display=on?'flex':'none'; };
window.appEngineDown=engineDown;
window.appFullScreen=on=>{ document.documentElement.classList.toggle('fs',!!on); reportDrag(); };
window.appFlush=async()=>{ const a=document.activeElement; if(a&&a.blur&&inField(a)) a.blur(); await saveNow(); };
// (with where the window was: its view, the picture on screen, the order and the pictures to check; the engine hands
//  them back to the page it loads after a restart, so it opens where it was)
window.appSnapshot=()=>{ if(!(st&&st.folder)) return ''; if(D) commit(); const p=D&&pics[order[cur]];
  return JSON.stringify({paths:[st.folder],only:st.only||undefined,fixes:D?fixes:undefined,history:D?{undo:hist.undo,redo:hist.redo,at:JSON.stringify(canon(fixes))}:undefined,
    ui:D?{view,id:p?p.id:null,pair,redFirst,flagged:[...flagged]}:undefined}); };
// (while an export runs nothing else is opened: that would stop it.  Said on the export's cover; the drop is ignored)
// (from the moment another folder is asked for until the window has heard back, keys and menu commands are not taken:
//  a change made then would be to the folder that is going, and could not be saved)
let opening=0;
window.appOpen=async paths=>{ if(exporting()){ $('bnote').textContent='Exporting: open another folder when it is done'; return; }
  opening++; try{ try{ await window.appFlush(); }catch(e){} try{ await post('/open',{paths}); }catch(e){} await poll(); } finally{ opening--; } };
window.appUndo=back=>{ if(inField(document.activeElement)){ document.execCommand(back?'undo':'redo'); return; } if(D&&!opening&&onMain()&&!anyOv()) doUndo(back); };
window.appSay=t=>msg(t);
// The keys beside the values in Single's bottom bar (engine 61): on unless he hides them; the app keeps the
// choice in its own preferences (never in fixes.json) and hands it back when the page loads.
let keyHints=true;
function setKeyHints(on,tell){ keyHints=!!on; document.documentElement.classList.toggle('nokeys',!keyHints); $('bkh').textContent=keyHints?'Hide keys':'Show keys'; if(tell) native({cmd:'pref',key:'keyHints',on:keyHints}); }
// (at every width: under 1080 points the keys wrap onto rows of their own; the top bar's KEYS opens the sheet; engine 66 #6)
$('bkh').onclick=()=>{ setKeyHints(!keyHints,true); $('bkh').blur(); };
window.appPrefs=p=>{ if(p&&typeof p.keyHints==='boolean') setKeyHints(p.keyHints,false); };

// The top strip of the window moves it when dragged; the app needs to know where the header's
// buttons are, so that those still take clicks.
let dragSent='';
function reportDrag(){
  if(!hasNative) return;
  let h=38, holes=[];
  if(['help','report','zoom','reset','about','mine'].some(i=>$(i).style.display==='flex')) h=0;
  else if(onMain()){ const t=$('top'); h=t.offsetHeight; t.querySelectorAll('button').forEach(b=>{ const r=b.getBoundingClientRect(); if(r.width) holes.push([r.left,r.top,r.width,r.height].map(Math.round)); }); }
  const s=JSON.stringify([h,holes]); if(s!==dragSent){ dragSent=s; native({cmd:'drag',h,holes}); }
}
setInterval(reportDrag,500);

async function apply(){
  const key=st.out+'|'+st.runs, sameFolder=D&&loadedKey.slice(0,loadedKey.lastIndexOf('|'))===st.out;
  native({cmd:'title',title:st.folder?folderName(st.folder)+' — 412 Film':''});
  if(st.phase==='working'){ if(wantView) wantSeen=true;
    const pct=(st.total?Math.round(100*st.done/st.total):0)+'%', name=st.folder?folderName(st.folder):'';
    // (scans of the open folder dropped on the window are made under the same cover as an export: the view and the
    //  picture stay where they were)
    if(sameFolder&&(st.runs>0||st.has_results)){ $('busy').style.display='flex'; $('bmsg').textContent=(st.only&&st.only.length?'Making the '+(st.only.length===1?'dropped scan':st.only.length+' dropped scans')+' of ':'Exporting ')+name; $('bstep').textContent=progress(false); $('bbar').style.width=pct; }
    else { D=null; loadedKey=''; $('busy').style.display='none'; screen('s-work'); $('wfolder').textContent='Opening '+name; $('wmsg').textContent=progress(true); $('wbar').style.width=pct;
      const pend=st.pending>0?'Making your '+st.pending+' change'+(st.pending===1?'':'s')+' that '+(st.pending===1?'was':'were')+' not yet exported':'';
      $('wsub').textContent=[pend,st.elsewhere?'This folder cannot be written to: the pictures go to '+st.out:''].filter(Boolean).join(' · '); }
    return;
  }
  // (after an export the cover stays until the new pictures and settings are loaded: a key pressed
  //  in that moment would otherwise change settings that are just about to be replaced)
  if(!(st.phase==='ready'&&st.has_results&&key!==loadedKey)){ $('busy').style.display='none'; $('bnote').textContent=''; }
  // something the engine has to say is shown once, when there is a screen to show it on (not over a progress bar)
  const fresh=st.tell&&st.tell.id!==toldId?st.tell:null; if(fresh) toldId=fresh.id;
  if(st.phase==='need_dng'){ D=null; loadedKey=''; screen('s-dng'); return; }
  if(st.phase==='ready'&&st.has_results){
    if(key!==loadedKey){ const first=!sameFolder, had=new Set(pics.map(q=>q.id)); holdSel(); try{ await loadData(); } finally{ $('busy').style.display='none'; } loadedKey=key;
      // (a folder that holds one roll opens on the Grid, however often it has been opened, unless that roll's type or
      //  film changed since its last export (Rolls, where Review exports first); one with more rolls opens on Rolls;
      //  after a restart it opens where it was)
      // The pictures to check are those flagged when the folder was opened: they stay in that group, in their places,
      // for as long as it is open (one he has checked shows a tick), and are grouped afresh the next time it is opened.
      if(first) flagged=new Set(pics.filter(q=>q.check).map(q=>q.id)); else pics.forEach(q=>{ if(q.check&&!had.has(q.id)) flagged.add(q.id); });
      // (the previous folder's order must not be read against this folder's pictures: it starts on the first)
      // (the views of the last folder, clipping, outside the crop and the diptych view, are not carried into this one)
      const rs=first&&st.resume&&st.resume.out===st.out&&st.resume.n!==resumed?st.resume:null; if(rs) resumed=rs.n;
      if(first){ held=null; order=[]; cur=0; sel.clear(); asideSel=null; redFirst=true; clip=false; ctx=false; pair=false;
        if(rs){ redFirst=rs.redFirst!==false; if(Array.isArray(rs.flagged)) rs.flagged.forEach(i=>{ if(pics.some(q=>q.id===i)) flagged.add(i); }); }
        setOrder(); cur=0;
        // (after a restart: the view and the picture it was on)
        if(rs){ const k=rs.id?order.findIndex(x=>pics[x].id===rs.id):-1; if(k>=0) cur=k; const q=pics[order[cur]]; pair=!!rs.pair&&rs.view==='single'&&!!q&&canPair(q); setView(rs.view||'rolls'); }
        else setView((D.rolls||[]).length<=1&&!rollTypeChanged()?'grid':'rolls'); } else { setOrder(); setView(wantView||view); wantView=null; }
      if(st.summary&&!first&&!fresh) sayExported();
      else if(first&&!fresh){ const n=pics.filter(q=>!q.skipped).length, sc=+((/ from (\d+) scans?/.exec(st.summary||D.summary||'')||[0,0])[1]);
        // (a folder with no pictures at all says so, and why, rather than "0 pictures in …"; engine 66 #9)
        if(!pics.length) msg(sc?'No pictures: all '+pl(sc,'scan')+(sc===1?' is':' are')+' blank or leader':'No pictures in this folder',0,null,true);
        else msg(pl(n,'picture')+' in '+where()+' (click to show)',0,st.out,true,true); } }
    // (an export that was cancelled leaves the view where it was; until the export has begun, the wanted view waits:
    //  a look at the engine in the moment before it starts must not drop it)
    if(wantView&&wantSeen&&st.runs===wantRun) wantView=null;
    if(fresh) msg(fresh.text,fresh.bad,fresh.reveal,fresh.hold);
    screen('s-main'); return;
  }
  // start (also after an error)
  D=null; loadedKey=''; wantView=null; screen('s-start');
  if(fresh){ startNote=fresh.text; startBad=!!fresh.bad; clearTimeout(apply.t); apply.t=setTimeout(()=>{ startNote=''; },6000); }
  // (in red only what went wrong: a plain word from the engine, "Stopped." after a Cancel, in the normal colour)
  $('startmsg').classList.toggle('plain',!st.error&&!!startNote&&!startBad);
  $('startmsg').innerHTML=esc(st.error||startNote||'')+(st.phase==='error'&&st.folder?' &nbsp;<button id="again">Try again</button>':'');
  const a=$('again'); if(a) a.onclick=()=>(st.out?post('/export'):post('/open',{paths:[st.folder]})).then(poll);
  // (each row: the folder, with its parent when its name says little; what was made; when, in words; × takes it off the list)
  const rk_=JSON.stringify((st.recent||[]).map(r=>[r.folder,r.summary,r.when,r.changes]));
  if($('recent')._k!==rk_){ $('recent')._k=rk_;
    $('recent').innerHTML=(st.recent||[]).length?'<h3>Recent</h3>'+st.recent.map((r,i)=>'<div class="rec" data-i="'+i+'" title="'+esc(r.folder)+'"><b>'+esc(folderName(r.folder))+'</b><span class="dim">'+esc((r.summary||'')+(r.changes>0?' · '+r.changes+' change'+(r.changes===1?'':'s')+' not yet exported':''))+'</span><span class="sp"></span><span class="dim when">'+esc(friendlyWhen(r.when))+'</span><button class="forget" title="Take it off this list (the folder is not touched)">×</button></div>').join(''):'';
    document.querySelectorAll('.rec').forEach(e=>{ const r=st.recent[+e.dataset.i]; e.onclick=()=>post('/open',{paths:[r.folder]}).then(poll);
      e.querySelector('.forget').onclick=ev=>{ ev.stopPropagation(); post('/forget',{folder:r.folder}).then(poll); }; }); }
}
// The line after an export (engine 66 #5): how many pictures this export made (the engine counts the files it put in
// place: "Made 1 picture (14 in the folder)"), those a file of his is in the way of, those he keeps his own file for, and
// the old files that went to the Trash (Put Back brings one back).  Never more than was made.
// (a picture where he chose Keep mine is not in the folder's count; one he answered Keep mine for since that export
//  was counted in its summary: it is taken off)
const pl=(n,w)=>n+' '+w+(n===1?'':'s');
function exportedLine(){ const b=blockedIds().size, k=keptIds().size, sm=st.summary||'', m=/^(\d+) pictures?(?: and (\d+) diptychs?)?/.exec(sm), mb=st.binned&&st.binned[0]?st.binned[1]:0;
  const ks=+((/; (\d+) kept as your own files?$/.exec(sm)||[0,0])[1]), scans=+((/ from (\d+) scans?/.exec(sm)||[0,0])[1]);
  const all=m?Math.max(0,+m[1]+(+m[2]||0)-b-Math.max(0,k-ks)):0, made=Array.isArray(st.made)?Math.min(all,st.made[0]+st.made[1]):all;
  const blk=b+(b===1?' picture is':' pictures are')+' blocked by '+(b===1?'a file':'files')+' of yours';
  let t=!m?'Exported: '+sm:
    !all&&!b&&!k?(scans?'No pictures: all '+pl(scans,'scan')+(scans===1?' is':' are')+' blank or leader':'No pictures'):
    made?'Made '+pl(made,'picture')+(made!==all?' ('+all+' in the folder)':'')+(b?'; '+blk:''):
    b?'Nothing was made: '+blk:
    'Nothing to make: '+(all===1?'the picture in the folder is':'the '+all+' pictures in the folder are')+' up to date';
  if(k&&m) t+='; '+k+' kept as your own file'+(k===1?'':'s');
  const yb=(st.yours_binned||[]); if(yb.length) t+=' · your file'+(yb.length===1?' ':'s ')+yb.slice(0,3).join(', ')+(yb.length>3?' and '+(yb.length-3)+' more':'')+' went to the Trash';
  if(st.binned&&st.binned[0]) t+=' · '+(st.binned[0]===1?'the old file of 1 picture':'old files of '+st.binned[0]+' pictures')+' went to the Trash ('+(mb>=1e9?(mb/1e9).toFixed(1)+' GB':mb>=1e5?(mb/1e6).toFixed(1)+' MB':Math.max(1,Math.round(mb/1e3))+' KB')+')';
  return t; }
// (the line is marked as the Exported line, so an answer about a file of his can put it right)
function sayExported(){ msg(exportedLine(),0,null,true); $('msg')._exp=true; }
// the pictures where he chose Keep mine (his file stays; no picture is made there)
function keptIds(){ return new Set(Object.values((st&&st.kept_id)||{})); }
// Make the Picture Here After All (Picture menu, engine 66 #11): the file of his that he chose to keep at this picture's
// place is named, with its content, in the setting '/replace'; at the next export the picture is made there and his file
// goes to the Trash (as Replace with the new).  A setting like any other: ⌘Z takes it back, nothing is asked.
function keptFileOf(id){ const m=(st&&st.kept_id)||{}; return Object.keys(m).find(f=>m[f]===id)||null; }
function withdrawn(id){ const f=keptFileOf(id), h=f&&((st&&st.kept_h)||{})[f]; return !!h&&(fixes['/replace']||{})[f]===h; }
function replaceAfterAll(p){ const f=keptFileOf(p.id), h=f&&((st&&st.kept_h)||{})[f]; if(!h||withdrawn(p.id)) return;
  snap(); fixes['/replace']={...(fixes['/replace']||{}),[f]:h}; after();
  msg('Your file '+base(f)+' goes to the Trash at the next export, and '+short(p.id)+' is made in its place (⌘Z takes this back)'); }
// the pictures a file of his own is in the way of (not made at the last export; "decide later" leaves them so)
function blockedIds(){ const m=(st&&st.blocked_id)||{}, b=new Set((st&&st.blocked)||[]), o=new Set();
  Object.keys(m).forEach(f=>{ if(b.has(f)){ const i=m[f]; o.add(i); if(/_diptych$/.test(i)) pics.filter(q=>q.scan===i.replace(/_diptych$/,'')).forEach(q=>o.add(q.id)); } }); return o; }
// What a run is doing, in words, with a count (the first opening of a folder goes through two steps, each with its own bar)
function progress(steps){
  const m=st.msg||'', n=st.total?(st.done||0)+' of '+st.total:'';
  const step=(i,t)=>(steps?'Step '+i+' of 2: '+t.toLowerCase():t)+(n?': '+n:'');
  if(/^Finding the pictures/.test(m)) return step(1,'Finding the pictures');
  if(/^Making the pictures/.test(m)) return step(2,'Making the pictures');
  if(/^Converting NEF to DNG/.test(m)) return 'Converting the camera files to DNG'+(n?': '+n:'');
  if(!m||m==='Starting') return 'Getting ready';
  return m+(n?': '+n:'');
}
async function loadData(){
  const d=await (await fetch('/data')).json(); if(!d||!d.pics) throw 0; const sameAsLoaded=D&&Dout===st.out;
  D=d; Dout=st.out; D.aside=D.aside||[]; pics=D.pics;
  // (engine 66 #9) a roll with no picture at all (a single empty frame the converter grouped as a roll) is not shown as
  // one: its scan is among those in no roll, and the rolls are numbered as shown.  Only the window's grouping; nothing
  // the converter makes changes.  The frames set aside are listed in name order.
  { const keep=(D.rolls||[]).filter(r=>pics.some(q=>q.roll===r.n)); if(keep.length!==(D.rolls||[]).length){ const to={}; keep.forEach((r,i)=>{ to[r.n]=i+1; });
      pics.forEach(q=>{ q.roll=to[q.roll]||q.roll; }); D.rolls=keep.map((r,i)=>({...r,n:i+1})); } }
  D.aside.sort((a,b)=>String(a.id).localeCompare(String(b.id),undefined,{numeric:true})); fixes=D.fixes||{}; ver=Date.now(); exportedC=canon(D.exported||fixes); listKey=''; gridKey=''; baseStr=null;
  // the undo history comes back with the folder, as long as it belongs to the settings as they are now
  if(!sameAsLoaded){ const h=D.history; hist=(h&&h.at===JSON.stringify(canon(fixes))&&Array.isArray(h.undo)&&Array.isArray(h.redo))?{undo:h.undo,redo:h.redo}:{undo:[],redo:[]};
    hist.undo.concat(hist.redo).forEach(x=>{ if(x) x.tag=null; }); }   // (yesterday's last step and today's first are two steps)
  $('fname').textContent=folderName(st.folder); $('fname').title=st.folder;
  const e=$('elsewhere'); e.style.display=st.elsewhere?'block':'none'; e.textContent=st.elsewhere?'This folder cannot be written to, so the pictures and converted files are in '+st.out:'';
  dirty();  askMine();
}
// Settings in one fixed form (nothing that is still automatic, keys in order), so two sets can be
// compared: what is on screen against what the files on disk were last made with.
function canon(fxs){
  const o={};
  Object.keys(fxs||{}).sort().forEach(k=>{ const v=fxs[k]; if(!v) return;
    if(k==='/options'){ const a=[...new Set(v)].sort(); if(a.length) o[k]=a; return; }
    if(k==='/replace'){ const r={}; Object.keys(v).sort().forEach(f=>{ if(typeof v[f]==='string') r[f]=v[f]; }); if(Object.keys(r).length) o[k]=r; return; }
    if(k.startsWith('/roll')){ const r={mode:v.mode||null,film:v.film||null,note:String(v.note||'').trim().replace(/\s+/g,' ').slice(0,200),sat:r2(+v.sat||0),warm:r2(+v.warm||0),tint:r2(+v.tint||0)};
      if(r.mode||r.film||r.note||r.sat||r.warm||r.tint){ if(k[5]==='/'&&Array.isArray(v.members)&&v.members.length) r.members=v.members.map(String).sort(); o[k]=r; } return; }
    const c=(v.crop||[0,0,0,0]).map(x=>Math.round(+x||0));
    const f={turn:(((+v.turn||0)%4)+4)%4,at:v.at>=0?(+v.at)%4:-1,density:r2(+v.density||0),contrast:r2(+v.contrast||0),skip:v.skip?1:0,mirror:v.mirror?1:0,ok:v.ok?1:0,crop:c,tilt:r2(+v.tilt||0),
      diptych:Math.sign(+v.diptych||0),closed:Math.sign(+v.closed||0),keep:v.keep?1:0,sat:r2(+v.sat||0),warm:r2(+v.warm||0),tint:r2(+v.tint||0)};
    if(f.turn||f.at>=0||f.density||f.contrast||f.skip||f.mirror||f.ok||c.some(x=>x)||f.tilt||f.diptych||f.closed||f.keep||f.sat||f.warm||f.tint) o[k]=f; });
  return o;
}
// The settings as far as they make the files: a checked mark (ok, and the way up it pinned, at) changes no file, so
// Return lights neither Export All nor "to export" (engine 66 #4)
function forFiles(c){ const o={}; Object.keys(c).forEach(k=>{ const v=c[k]; if(k.startsWith('/')||!v||typeof v!=='object'||Array.isArray(v)){ o[k]=v; return; }
  const f={...v,ok:0,at:v.turn?v.at:-1}; if(f.turn||f.density||f.contrast||f.skip||f.mirror||(f.crop||[]).some(x=>x)||f.tilt||f.diptych||f.closed||f.keep||f.sat||f.warm||f.tint) o[k]=f; }); return o; }
const same=(a,b)=>JSON.stringify(a===undefined?null:a)===JSON.stringify(b===undefined?null:b);
// does this picture's file on disk differ from what the settings now ask for?  (shown as "to export")
function dirty(){ markStale();
  if(D){ const nf=st&&st.failed?Object.keys(st.failed).length:0, ns=st&&st.strays?st.strays.length:0, t=(D.summary||'')+(nf?' · '+nf+' scan'+(nf===1?'':'s')+' could not be made (see Report)':'')+(ns?' · '+ns+' JPEG/TIFF file'+(ns===1?'':'s')+' with no RAW scan not used':''), N=pics.filter(isFlagged).length, left=pics.filter(isRed).length, c=N?(N-left)+' of '+N+' checked':'';
    if($('fsum').textContent!==t) $('fsum').textContent=t; $('fsum').style.color=nf?'var(--flag-soft)':''; $('fsum').title=ns?'Not used (no RAW scan of the same name): '+st.strays.slice(0,8).join(', ')+(ns>8?' and '+(ns-8)+' more':''):''; if($('fcheck').textContent!==c) $('fcheck').textContent=c; $('fcheck').classList.toggle('done',!left);
    $('fcheck').title=N?(left?left+' still to check (outlined in red)':'Every picture that was flagged has been checked'):''; }
  const d=JSON.stringify(forFiles(canon(fixes)))!==JSON.stringify(forFiles(exportedC))||(!!D&&blockedIds().size>0), rt=D&&rollTypeChanged();
  $('bexport').classList.toggle('quiet',!d);
  const g=rt?ROLLGO_TYPE:'Review the pictures'; if($('rollgo').textContent!==g) $('rollgo').textContent=g;
  $('rollhint').textContent=d&&!rt?'Changes are made into the pictures when you export.':''; return d; }
// (what the Rolls button reads then: the messages that send him there say these very words; engine 66 #7)
const ROLLGO_TYPE='Export and review (roll type changed)';
// a roll's type (half / full frame) or film changed since the pictures were made: they are different pictures, so the
// Rolls screen's button exports first.  Anything else is reviewed as it is and made at the next export.
function rollTypeChanged(){ const c=canon(fixes), e=exportedC;
  return [...new Set(Object.keys(c).concat(Object.keys(e)))].some(k=>k.startsWith('/roll')&&(((c[k]||{}).mode||null)!==((e[k]||{}).mode||null)||((c[k]||{}).film||null)!==((e[k]||{}).film||null))); }
// flagged for checking when the folder was opened (or since, for a new picture); red while not yet checked
const isFlagged=p=>!p.skipped&&(flagged.has(p.id)||!!p.check);
const skippedNow=p=>!!get(p.id).skip||(!p.full&&!!get(p.scan).skip);
const isRed=p=>!!p.check&&!get(p.id).ok&&!skippedNow(p);      // (skipping a flagged picture deals with it too)

// ------------------------------------------------------------------ rolls

function drawRolls(){
  if(!D) return;
  const o=fixes['/options']||[];
  document.querySelectorAll('#v-rolls input[data-o]').forEach(c=>{ c.checked=o.includes(c.dataset.o); c.onchange=()=>{ snap(); const s=new Set(fixes['/options']||[]); c.checked?s.add(c.dataset.o):s.delete(c.dataset.o); fixes['/options']=[...s]; save(); dirty(); }; });
  // scans in no roll at all (a blank holder between rolls, a leader): said here, so the rolls' counts add up
  { const inRoll=new Set((D.rolls||[]).flatMap(r=>r.members||[])), out=(D.aside||[]).filter(a=>a.id===a.scan&&!inRoll.has(a.scan)), nr=$('noroll');
    const whys=[...new Set(out.map(a=>a.why||'set aside'))].join(', ');
    nr.style.display=out.length?'block':'none';
    nr.innerHTML=out.length?esc(out.length===1?'1 scan is not in a roll ('+whys+')':out.length+' scans are not in a roll ('+whys+')')+': see <a href="#" id="norollgo">Not made into pictures</a> at the end of the Grid.':'';
    const g=$('norollgo'); if(g) g.onclick=e=>{ e.preventDefault(); asideSel=out[0].id; sel.clear(); goView('grid'); if(view==='grid'){ drawGrid(); info(); const a=document.querySelector('#grid .as.cur'); if(a) a.scrollIntoView({block:'nearest'}); } }; }
  const W=$('rollcards'); W.innerHTML='';
  D.rolls.forEach(r=>{ const key=rk(r.n), c=rollFx(r.n), mine=pics.filter(p=>p.roll===r.n&&!p.skipped), step=Math.max(1,Math.ceil(mine.length/14));
    const d=document.createElement('div'); d.className='card';
    d.innerHTML='<div class="rc"><div class="hd"><b>Roll '+(+r.n)+'</b><div class="dim">'+esc(r.first)+' – '+esc(r.last)+'</div><div class="dim">'+mine.length+' picture'+(mine.length===1?'':'s')+' from '+(+r.count)+' scan'+(+r.count===1?'':'s')+'</div></div>'+
      '<div><div class="ctl"><select class="m"><option value="">Automatic ('+esc(r.auto_mode)+' frame)</option><option value="half">Half frame</option><option value="full">Full frame</option></select>'+
      '<select class="f"><option value="">Automatic ('+(r.auto_film==='colour'?'colour':'black-and-white')+')</option><option value="colour">Colour</option><option value="bw">Black-and-white</option></select>'+
      '<input type="text" maxlength="200" placeholder="Film and camera, e.g. Tri-X 400, Pen FT"><button class="rr" title="Everything changed on this roll goes back to automatic (⌘Z brings it back)">Reset roll</button></div>'+
      '<div class="strip">'+mine.filter((p,i)=>i%step===0).map(p=>'<span class="sb" data-id="'+esc(p.id)+'"><img src="/thumb/'+U(p.id)+'.jpg?v='+ver+'"></span>').join('')+'</div></div></div>';
    const s=d.querySelector('select.m'), fl=d.querySelector('select.f'), i=d.querySelector('input'); s.value=c.mode||''; fl.value=c.film||''; i.value=c.note||'';
    const put=()=>{ snap(); fixes[key]={...rollFx(r.n),mode:s.value||null,film:fl.value||null,note:i.value}; save(); dirty(); };
    // (focus leaves the menu once a choice is made: the keys, undo included, work again at once)
    s.onchange=()=>{ put(); s.blur(); }; fl.onchange=()=>{ put(); fl.blur(); };
    // the note is kept as it is typed, and all of one visit to the box is one undo step
    let noteTag=null; i.onfocus=()=>{ noteTag='note'+(++tagN); }; i.oninput=i.onchange=()=>{ tagNow=noteTag||('note'+(++tagN)); put(); tagNow=null; };
    const rb=d.querySelector('button.rr'); if(rb) rb.onclick=()=>resetRoll(r.n);
    // a click on a picture in the strip goes to that picture in the Grid (elsewhere on the strip: the roll's first)
    d.querySelector('.strip').onclick=e=>{ const b=e.target.closest('.sb'), id=b&&b.dataset.id; let k=id?order.findIndex(x=>pics[x].id===id):-1;
      if(k<0) k=order.findIndex(x=>pics[x].roll===r.n); if(k>=0){ cur=k; sel.clear(); asideSel=null; } goView('grid'); };
    const strip=d.querySelector('.strip');
    d.querySelectorAll('.strip .sb').forEach(b=>{ const q=pics.find(x=>x.id===b.dataset.id), i=b.querySelector('img'); if(!q||!i) return; i.onload=()=>{ stripTf(b,q); fitStrip(strip); }; stripTf(b,q); });
    W.appendChild(d); fitStrip(strip); });
}
// A roll's strip shows as many of its pictures as fit, spread evenly from its first to its last: none is cut off at the
// right edge (a tall picture is narrower than a wide one, so it is measured, not counted)
function fitStrip(strip){ if(!strip) return; const bs=[...strip.querySelectorAll('.sb')]; if(!bs.length) return;
  bs.forEach(b=>b.style.display=''); const room=strip.clientWidth-8, gap=4, w=bs.map(b=>b.offsetWidth);
  if(!room||w.reduce((a,x)=>a+x+gap,0)-gap<=room) return;
  for(let n=bs.length-1;n>=1;n--){ const pick=new Set(n===1?[0]:[...Array(n).keys()].map(i=>Math.round(i*(bs.length-1)/(n-1))));
    if([...pick].reduce((a,i)=>a+w[i]+gap,0)-gap<=room){ bs.forEach((b,i)=>b.style.display=pick.has(i)?'':'none'); return; } }
}
// A strip picture turned by the window (thumbTf) keeps the strip's height: a quarter turn makes the box as wide as
// the picture is now tall, and the picture is sized so that, turned, it fits that box.
function stripTf(b,p){ const i=b.querySelector('img'), w=i.naturalWidth, h=i.naturalHeight; if(!w||!h) return; const H=66, t=thumbTf(p), q=/^rotate\((90|270)deg\)/.test(t)!==/rotate\(-(90|270)deg\)$/.test(t);
  // (thumbTf is rotate(N) [mirror] rotate(-T): the picture ends up a quarter turn off when exactly one of N, T is odd)
  if(q){ b.style.width=Math.round(H*h/w)+'px'; i.style.width=H+'px'; i.style.height=Math.round(H*h/w)+'px'; } else { b.style.width=Math.round(H*w/h)+'px'; i.style.width=Math.round(H*w/h)+'px'; i.style.height=H+'px'; }
  if(i.style.transform!==t) i.style.transform=t; }

// ------------------------------------------------------------------ list and grid

let held=null;
function holdSel(){ if(held) return; const id=k=>{ const p=pics[order[k]]; return p?p.id:null; }, p=pics[order[cur]]; held={cur:id(cur),scan:p?p.scan:null,sel:[...sel].map(id).filter(Boolean)}; }
// (a picture that is gone, e.g. a roll made half-frame: the same scan's picture, else the first; never wherever the
//  old position happens to fall; engine 66 #8)
function restoreSel(){ if(!held) return; const at=i=>order.findIndex(k=>pics[k].id===i), c=held.cur===null?-1:at(held.cur), s=c<0&&held.scan!==null?order.findIndex(k=>pics[k].scan===held.scan):-1;
  cur=c>=0?c:s>=0?s:0; sel=new Set(held.sel.map(at).filter(k=>k>=0)); held=null; }
function setOrder(){
  holdSel();                                  // (taken before the list changed, where the caller knew it was about to)
  order=pics.map((p,i)=>i);
  if(redFirst) order.sort((a,b)=>(isFlagged(pics[b])?1:0)-(isFlagged(pics[a])?1:0)||a-b);
  $('order').textContent=redFirst?'To check first':'As on the film'; $('order').title=redFirst?'The pictures to check come first. Click to show them as on the film':'The pictures in film order. Click to show those to check first';
  restoreSel();
  cur=Math.max(0,Math.min(order.length-1,cur));
}
const TOCHECK='To check';
// (with nothing to check at all, the pictures are under their rolls' headings in either order: "The rest" alone says nothing)
// (after the pictures to check, the rest are under their rolls' headings, as on the film)
const groupOf=p=>redFirst&&pics.some(isFlagged)&&isFlagged(p)?TOCHECK:'Roll '+p.roll+(D.rolls[p.roll-1]&&D.rolls[p.roll-1].note?' · '+D.rolls[p.roll-1].note:'');
// the heading of the pictures to check says how many are left (it is built once; the count is kept up to date)
function headText(g){ if(g!==TOCHECK) return g; const left=pics.filter(isRed).length; return g+' ('+(left?left+' left':'all checked')+')'; }
function heads(root){ root.querySelectorAll('[data-g]').forEach(h=>{ const t=headText(h.dataset.g); if(h.textContent!==t) h.textContent=t; }); }
// a picture that was flagged and has been checked: a tick in place of the red outline (it keeps its place)
const isOkd=p=>isFlagged(p)&&!isRed(p);
function cellTitle(d,p){ const t=isRed(p)?'Check: '+checkWords(p).lead+(checkWords(p).also.length?' (and '+checkWords(p).also.length+' more)':''):isOkd(p)?(skippedNow(p)?'Skipped':'Checked'):''; if(d.title!==t) d.title=t; }
function tagsOf(p,f,sf){
  let t=''; if(f.skip) t+='<span class="tag">skip</span>'; if(!p.full&&dipOn(sf)) t+=dipMade(p)?'<span class="tag">diptych</span>':'<span class="tag" title="The diptych is not made: a half is skipped">diptych not made</span>';
  if(f.turn||f.density||f.contrast||f.mirror||f.tilt||f.sat||f.warm||f.tint||(f.crop||[]).some(v=>v)) t+='<span class="tag">edited</span>';
  if(blockedIds().has(p.id)) t+='<span class="tag exp" title="Not made at the last export: a file of yours is in the way (Export All asks again)">not made</span>';
  else if(keptIds().has(p.id)) t+=withdrawn(p.id)?'<span class="tag exp" title="Your own file goes to the Trash at the next export and this picture is made in its place (⌘Z takes it back)">to export</span>':
    '<span class="tag" title="Your own file is kept where this picture would go (Keep mine): no picture is made there. Picture › Make the Picture Here After All changes that">your file</span>';
  else if(staleNow.has(p.id)) t+='<span class="tag exp">to export</span>'; return t;
}
function pick(e,k,dbl){
  asideSel=null;
  if(e.metaKey){ sel.has(k)?sel.delete(k):sel.add(k); }
  else if(e.shiftKey){ for(let i=Math.min(cur,k);i<=Math.max(cur,k);i++) sel.add(i); }
  else { sel.clear(); cur=k; }
  if(view==='single'||dbl){ if(dbl) setView('single'); else show(cur); } else { drawGrid(); info(); }
}
// Scans the converter set aside (blank, fogged, leader, an empty half): shown at the end, each with
// what it looks like and why, so one that is a real picture can be brought back from here.
const asideOf=id=>(D.aside||[]).find(a=>a.id===id);
function toggleKeep(id){ if(!asideOf(id)) return; snap(); const f=fx(id); f.keep=f.keep?0:1; asideSel=id; after(); msg(f.keep?'It will be made into a picture at the next export':'Left aside again'); }
function asideHTML(a,cls){
  return '<div class="im"><img loading="lazy" src="/aside/'+U(a.scan)+'.jpg?v='+ver+'"></div><div class="nm"><b>'+esc(short(a.id))+'</b></div><div class="why">'+esc(a.why||'set aside')+'</div><button class="'+cls+'"></button>';
}
function asideState(d,a){ const on=!!get(a.id).keep; d.classList.toggle('exp',!same(canon(fixes)[a.id],exportedC[a.id])); d.classList.toggle('keep',on); d.classList.toggle('cur',asideSel===a.id); const b=d.querySelector('button'), t=on?'Leave aside':'Make a picture'; if(b.textContent!==t) b.textContent=t; }
function asideBuild(parent,prefix,cls){
  if(!(D.aside||[]).length) return;
  parent.insertAdjacentHTML('beforeend','<div class="'+(prefix==='as'?'gh':'roll')+'">Not made into pictures</div>');
  const wrap=document.createElement('div'); wrap.className=prefix==='as'?'gw':''; parent.appendChild(wrap);
  D.aside.forEach((a,i)=>{ const d=document.createElement('div'); d.id=prefix+i; d.className=cls; d.innerHTML=asideHTML(a,'mk');
    d.onclick=()=>{ asideSel=a.id; sel.clear(); paint(); drawGrid(); drawList(); info(); };
    d.querySelector('button').onclick=e=>{ e.stopPropagation(); toggleKeep(a.id); };
    wrap.appendChild(d); });
}
let listKey='', gridKey='';
const buildKey=()=>order.join(',')+'|'+ver+'|'+redFirst+'|'+JSON.stringify(D.rolls.map(r=>r.note))+'|'+(D.aside||[]).length;
let staleNow=new Set();
// A thumbnail is the picture as last exported.  Until the next export it is turned (and mirrored) here by
// the difference between the settings it was made with and the settings now, so a turn shows at once.
// (as turned(): the mirror is taken first, then the turn; CSS applies the rightmost transform first)
function thumbTf(p){
  const e=exportedC[p.id]||NOFIX, f=get(p.id), T=(((e.at>=0?e.at:p.auto_turns)+(e.turn||0))%4+4)%4, N=((autoT(p,f)+(f.turn||0))%4+4)%4, m=!!f.mirror!==!!e.mirror;
  return N===T&&!m?'':'rotate('+N*90+'deg)'+(m?' scaleX(-1)':'')+' rotate('+(-T*90)+'deg)';
}
function setTf(d,p){ const i=d.querySelector('img'); if(!i) return; const t=thumbTf(p); if(i.style.transform!==t) i.style.transform=t; }
function markStale(){ const c=forFiles(canon(fixes)), e=forFiles(exportedC), opt=!same(c['/options'],e['/options']), bl=blockedIds(); staleNow=new Set(pics.filter(p=>opt||bl.has(p.id)||withdrawn(p.id)||!same(c[p.id],e[p.id])||!same(c[p.scan],e[p.scan])||!same(c[rk(p.roll)],e[rk(p.roll)])).map(p=>p.id)); }
function drawList(){
  if(view!=='single') return;
  const L=$('list'), key=buildKey();
  if(key!==listKey){                         // build only when the pictures themselves change
    listKey=key; L.innerHTML=''; let last=null;
    order.forEach((pi,k)=>{ const p=pics[pi], g=groupOf(p);
      if(g!==last){ L.insertAdjacentHTML('beforeend','<div class="roll" data-g="'+esc(g)+'">'+esc(headText(g))+'</div>'); last=g; }
      const d=document.createElement('div'); d.id='it'+k;
      d.innerHTML=(p.skipped?'<div class="ph"></div>':'<img loading="lazy" src="/thumb/'+U(p.id)+'.jpg?v='+ver+'">')+'<div><div class="nm">'+esc(short(p.id))+'</div><div class="sub"></div></div>';
      d.onclick=e=>pick(e,k,false); L.appendChild(d); });
    asideBuild(L,'al','as it');
  }
  order.forEach((pi,k)=>{ const p=pics[pi], f=get(p.id), sf=get(p.scan), d=$('it'+k); if(!d) return;
    d.className='it'+(k===cur&&asideSel===null?' cur':'')+(sel.has(k)?' sel':'')+(isRed(p)?' check':'')+(isOkd(p)?' okd':'')+(f.skip||(!p.full&&sf.skip)?' skip':'');
    const sub=d.querySelector('.sub'), t=tagsOf(p,f,sf); if(sub.innerHTML!==t) sub.innerHTML=t; setTf(d,p); cellTitle(d,p); });
  heads(L);
  (D.aside||[]).forEach((a,i)=>{ const d=$('al'+i); if(d) asideState(d,a); });
  const c=asideSel===null?$('it'+cur):null; if(c) c.scrollIntoView({block:'nearest'});
}
function drawGrid(){
  if(view!=='grid') return;
  const G=$('grid'), key=buildKey();
  if(key!==gridKey){
    gridKey=key; G.innerHTML=''; let last=null, wrap=null;
    order.forEach((pi,k)=>{ const p=pics[pi], g=groupOf(p);
      if(g!==last){ G.insertAdjacentHTML('beforeend','<div class="gh" data-g="'+esc(g)+'">'+esc(headText(g))+'</div>'); wrap=document.createElement('div'); wrap.className='gw'; G.appendChild(wrap); last=g; }
      const d=document.createElement('div'); d.id='t'+k;
      d.innerHTML='<div class="im">'+(p.skipped?'':'<img loading="lazy" src="/thumb/'+U(p.id)+'.jpg?v='+ver+'">')+'</div><div class="nm"><b>'+esc(short(p.id))+'</b><span class="tg"></span></div>';
      d.onclick=e=>pick(e,k,false); d.ondblclick=e=>pick(e,k,true); wrap.appendChild(d); });
    asideBuild(G,'as','as t');
  }
  order.forEach((pi,k)=>{ const p=pics[pi], f=get(p.id), sf=get(p.scan), d=$('t'+k); if(!d) return;
    d.className='t'+(k===cur&&asideSel===null?' cur':'')+(sel.has(k)?' sel':'')+(isRed(p)?' check':'')+(isOkd(p)?' okd':'')+(f.skip||p.skipped||(!p.full&&sf.skip)?' skip':'');
    const tg=d.querySelector('.tg'), t=tagsOf(p,f,sf); if(tg.innerHTML!==t) tg.innerHTML=t; setTf(d,p); cellTitle(d,p); });
  heads(G);
  (D.aside||[]).forEach((a,i)=>{ const d=$('as'+i); if(d) asideState(d,a); });
}
// (the same among the frames set aside, when the folder has no pictures to go to)
function rowStep(el,i,n,k){
  if(k==='ArrowLeft') return i-1; if(k==='ArrowRight') return i+1;
  const t=el(i); if(!t) return i; const x=t.getBoundingClientRect().left, y=t.getBoundingClientRect().top, dir=k==='ArrowDown'?1:-1; let best=null;
  for(let j=i+dir;j>=0&&j<n;j+=dir){ const r=el(j).getBoundingClientRect(); if(Math.abs(r.top-y)<2) continue;
    if(best===null||Math.abs(r.top-best.top)<2){ if(best===null||Math.abs(r.left-x)<Math.abs(best.left-x)) best={i:j,top:r.top,left:r.left}; } else break; }
  return best?best.i:i;
}
function gridMove(k){
  if(!order.length){ const A=D.aside||[]; if(!A.length) return; const i=A.findIndex(a=>a.id===asideSel);
    const j=i<0?0:Math.max(0,Math.min(A.length-1,rowStep(n=>$('as'+n),i,A.length,k))); asideSel=A[j].id; drawGrid(); info();
    const c=$('as'+j); if(c) c.scrollIntoView({block:'nearest'}); return; }
  const t=$('t'+cur); if(!t) return; let to=cur; asideSel=null;
  if(k==='ArrowLeft') to=cur-1; else if(k==='ArrowRight') to=cur+1;
  else { const x=t.getBoundingClientRect().left, y=t.getBoundingClientRect().top, dir=k==='ArrowDown'?1:-1; let best=null;
    for(let i=cur+dir;i>=0&&i<order.length;i+=dir){ const r=$('t'+i).getBoundingClientRect(); if(Math.abs(r.top-y)<2) continue;
      if(best===null||Math.abs(r.top-best.top)<2){ if(best===null||Math.abs(r.left-x)<Math.abs(best.left-x)) best={i,top:r.top,left:r.left}; } else break; }
    if(best) to=best.i; }
  to=Math.max(0,Math.min(order.length-1,to)); sel.clear(); cur=to; drawGrid(); info(); const c=$('t'+cur); if(c) c.scrollIntoView({block:'nearest'});
}
function show(k){
  if(!order.length){ showNone(); return; }
  asideSel=null;
  cur=Math.max(0,Math.min(order.length-1,k)); const p=pics[order[cur]];
  $('skipnote').style.display=p.skipped?'block':'none'; cv.style.display=p.skipped?'none':'';
  if(!p.skipped){ img.onload=paint; img.src='/review/'+U(p.id)+'.jpg?v='+ver; }
  drawList(); info();
}
// A folder with no pictures at all (only blank holders, film ends, fogged frames): nothing of the folder before stays
// on screen; the list holds the frames set aside, and the one selected (the first, to begin with) is shown.
function showNone(){
  const A=(D&&D.aside)||[]; if((asideSel===null||!asideOf(asideSel))&&A.length) asideSel=A[0].id;
  $('skipnote').style.display='none'; cv.width=1; cv.height=1; cv.getContext('2d').clearRect(0,0,1,1); geom=null;
  if(asideSel!==null&&asideOf(asideSel)){ cv.style.display=''; paint(); } else cv.style.display='none';
  drawList(); info();
}
function noPictures(as){
  const single=view==='single';
  if(!as) $('why').style.display='none';
  cv.style.opacity=''; document.documentElement.classList.remove('pairview');
  $('pos').textContent=as&&single?short(as.id)+' · not made into a picture':'No pictures in this folder';
  ['vd','vc','vs','vw','vt','vcrop','vtilt'].forEach(i=>{ if($(i)) $(i).textContent='–'; });
  $('satrow').style.display='none'; $('toroll').style.display='none'; $('flags').innerHTML=''; $('selinfo').textContent='';
}
function targets(){ const s=new Set(sel); s.add(cur); const ts=[...s].map(k=>pics[order[k]]).filter(Boolean), p=pics[order[cur]];
  // (in the diptych view both halves are on screen as one picture: what is changed is changed on both)
  if(view==='single'&&pair&&p&&canPair(p)) mates(p).forEach(h=>{ if(!ts.includes(h)) ts.push(h); }); return ts; }
function info(){
  if(!D) return;
  if(asideSel!==null&&!asideOf(asideSel)) asideSel=null;       // (a frame that is no longer set aside)
  const why=$('why'), as=asideSel!==null&&view!=='rolls'?asideOf(asideSel):null;
  if(as){ why.textContent=short(as.id)+' was not made into a picture: '+(as.why||'set aside')+'.  '+(get(as.id).keep?'It will be made at the next export (S or the button to leave it aside again).':'Press S or the button to make a picture of it, then Export All.');
    why.style.display='block'; why.style.color='var(--pale)'; }
  if(!order.length){ noPictures(as); return; }
  const p=pics[order[cur]], f=get(p.id), sf=get(p.scan), single=view==='single', pv=single&&pair&&canPair(p);
  // (nothing about a picture on Rolls, where no picture is on screen and Return does nothing)
  if(!as){ const cw=isRed(p)&&view!=='rolls'?checkWords(p):null, also=cw&&cw.also.length?'  Also: '+cw.also.join('; ')+'.':'', sk=view!=='rolls'&&!p.skipped&&skippedNow(p);
    // (in the diptych view a flagged half's reasons come first, each with its half; the view's own help only when neither is)
    const hs=pv?mates(p):[], red=hs.filter(isRed), both=single&&pair&&pairable(p)&&mates(p).every(skippedNow);
    const pw=red.map(h=>{ const c=checkWords(h); return (hs.indexOf(h)+1)+'/2: '+c.lead+(c.also.length?' (also: '+c.also.join('; ')+')':''); }).join('.  ');
    const wtxt=pv&&red.length?'Check '+pw+'.  Press Return if '+(red.length>1?'they look':'it looks')+' right (→ moves on without marking '+(red.length>1?'them':'it')+').':
      pv?'Diptych view: both halves as one picture.  The value keys change both halves; ⇧← ⇧→ rotate it; the Picture menu has the gap and View Pair (back to single pictures)':
      sk&&single&&both?'Skipped: both halves of '+short(p.scan)+' are not made at the next export, nor their diptych.  S brings them back.':
      sk&&single?'Skipped: '+short(p.id)+' is not made at the next export.  S brings it back.':
      !cw?'':single?'Check: '+cw.lead+'.'+also+'  Press Return if it looks right (→ moves on without marking it).':
      'Check '+short(p.id)+': '+cw.lead+'.'+also+'  Return opens it.';
    why.textContent=wtxt; why.style.display=wtxt?'block':'none'; why.style.color=pv&&!red.length?'var(--blue)':sk&&single?'var(--pale)':'var(--flag-soft)'; }
  cv.style.opacity=single&&!p.skipped&&skippedNow(p)&&!pv?'.3':'';
  document.documentElement.classList.toggle('pairview',!!pv);
  $('pos').textContent=as&&single?short(as.id)+' · not made into a picture':short(pv?p.scan:p.id)+(pv?' · both halves':'')+' · '+(cur+1)+' of '+order.length+' · roll '+p.roll;
  { const b=r2(-f.density||0); $('vd').textContent=(b>0?'+':'')+b.toFixed(2); }     // brightness: the density setting, the other way up
  $('vc').textContent=(f.contrast>0?'+':'')+r2(f.contrast).toFixed(2);
  $('satrow').style.display=p.colour?'inline':'none'; $('toroll').style.display=p.colour?'':'none';
  if(p.colour){ const r=rollFx(p.roll), sg=v=>(v>0?'+':'')+r2(v).toFixed(2); $('vs').textContent=sg((r.sat||0)+(f.sat||0)); $('vw').textContent=sg((r.warm||0)+(f.warm||0)); $('vt').textContent=sg((r.tint||0)+(f.tint||0)); }
  // the crop in words: in from the automatic crop (trimmed), out past it (wider), or both
  { const c=f.crop||[0,0,0,0], tr=c.some(v=>v>0), wd=c.some(v=>v<0); $('vcrop').textContent=tr&&wd?'trimmed, wider':tr?'trimmed':wd?'wider':'auto';
    // (the diptych view has no straighten of its own: "–", not a 0° it does not have; engine 66 #13)
    const t=r2(f.tilt||0); $('vtilt').textContent=pv?'–':t?(t>0?'+':'')+t.toFixed(1)+'°':'0°'; }
  let fl=''; if(f.skip) fl+='<span class="tag">SKIPPED</span>'; if(f.mirror) fl+='<span class="tag">mirrored</span>';
  if(!p.full&&dipOn(sf)) fl+=dipMade(p)?'<span class="tag">diptych'+(sf.closed>0?' (closed)':'')+'</span>':'<span class="tag">diptych not made: a half is skipped</span>';
  if(pair&&canPair(p)) fl+='<span class="tag">DIPTYCH VIEW</span>';
  if(clip) fl+='<span class="tag" title="Show Clipping is on (Picture menu)">clipping</span>'; if(ctx) fl+='<span class="tag" title="Show Outside the Crop is on (Picture menu)">outside shown</span>';
  $('flags').innerHTML=fl;
  $('selinfo').textContent=sel.size>1||(sel.size===1&&!sel.has(cur))?targets().length+' pictures selected':'';
}

// The reasons a picture is flagged (the converter's, joined by '; '), in plain words, the one with the likeliest
// thing to do first: not a picture at all (S skips it), the wrong way up, the crop, maybe only light leak, then what
// cannot be fixed here.
const REASONS=[
  [/^the film ends across it at the (start|end)/, m=>[0,'the film ends across it ('+m[1]+' of the roll): S skips it','the film ends across it']],
  [/^burn-in at the (start|end)/, m=>[0,'burn-in at the '+m[1]+' of the roll, kept as a picture: S skips it','burn-in']],
  [/^only soft bands and glows/, ()=>[3.5,'may be only light leak: if it is not a picture, S skips it','may be only light leak']],
  [/^very faint/, ()=>[1,'very faint: it may be an empty frame (S skips it)','very faint']],
  [/^not sure which way up/, ()=>[2,'it may be the wrong way up: ⇧← ⇧→ rotates it','may be the wrong way up']],
  [/^holder window not found cleanly/, ()=>[3,'the crop may be off (the holder window was not found cleanly): drag an edge to fix it','the crop may be off']],
  [/^no visible gap between the two pictures/, ()=>[3,'the split between the two pictures is a guess: check the side edges','the split is a guess']],
  [/no detail/, (m,t)=>{ const q=/(\d+)%/.exec(t); return [4,'the darkest parts of the picture have no detail'+(q?' ('+q[1]+'% of it)':'')+': the scan was too bright','the darkest parts have no detail']; }]];
function checkWords(p){
  // (an older folder's overexposure reason has a '; rescan darker ...' of its own: that is part of it, not another reason)
  const rs=String(p.check||'').split('; ').filter(t=>t&&!/^rescan darker/.test(t)).map(t=>{ for(const [re,fn] of REASONS){ const m=re.exec(t); if(m) return fn(m,t); } return [5,t,t]; }).sort((a,b)=>a[0]-b[0]);
  const lead=rs.length?rs[0][1]:''; return {lead:lead.charAt(0).toUpperCase()+lead.slice(1), also:rs.slice(1).map(r=>r[2])};
}

// ------------------------------------------------------------------ the picture

function toned(p,f,image){                   // the stored picture with this picture's brightness, contrast and colour
  const g=p.g*Math.pow(D.STEP,-f.density/0.25), s=Math.max(-0.6,Math.min(0.9,D.S_CURVE+D.CONTRAST_STEP*f.contrast/0.25));
  // (as the engine's lifted(): a lift, g under 1, fades to nothing at black, so black stays black)
  const kk=(D.TOE_K||0)*(1-g);
  // ... and a darkening (g over 1) reaches the deep shadows only in part
  const SS=D.SHADOW_SHARE===undefined?1:D.SHADOW_SHARE, ST=D.SHADOW_TO||0.5, gs=1+(g-1)*SS;
  const pw=x=>{ if(kk>0) return Math.pow(x,g)*x/(x+kk); const y=Math.pow(x,g); if(g>1&&SS<1){ let w=1-x/ST; w=w<0?0:w; return y+(Math.pow(x,gs)-y)*w*w; } return y; };
  const curve=x=>{ x=x<0?0:x>1?1:x; x=pw(x); x-=s*Math.sin(2*Math.PI*x)/(2*Math.PI); return x; };
  const W=image.naturalWidth, H=image.naturalHeight, c=document.createElement('canvas');
  c.width=W; c.height=H; const o=c.getContext('2d',{willReadFrequently:true}); o.drawImage(image,0,0);
  const im=o.getImageData(0,0,W,H), a=im.data;
  if(p.colour){
    const r=rollFx(p.roll), warm=(r.warm||0)+(f.warm||0), tint=(r.tint||0)+(f.tint||0), sat=Math.max(0,(p.sat0||D.COLOUR_SAT)+(r.sat||0)+(f.sat||0));
    const off=[warm, -tint, -warm].map(v=>v/p.dr), L=[new Float32Array(256),new Float32Array(256),new Float32Array(256)];
    // the same sums as the engine: room above white (HEAD) folded in by a shoulder from KNEE, then the curve;
    // more saturation only as far as fits between black and white
    const VB=p.vb===undefined?(D.VIBRANCE||0):p.vb, CS=p.cs===undefined?1:p.cs, VF=D.VIB_FROM||0, VT=D.VIB_TO||1, RS=D.ROOM_SOFT||0;
    const HEAD=D.HEAD||1, KNEE=D.KNEE||1, TOP=D.TOP||1, FOOT=D.FOOT||0, TOE=D.TOE||0, top=KNEE<1?(TOP-KNEE)/Math.tanh((HEAD-KNEE)/(1-KNEE)):0;
    const sh=x=>{ x=x<-FOOT?-FOOT:x>HEAD?HEAD:x; return x>KNEE&&KNEE<1?KNEE+top*Math.tanh((x-KNEE)/(1-KNEE)):(TOE>0&&x<TOE?TOE*Math.exp((x-TOE)/TOE):x); };
    for(let k=0;k<3;k++) for(let v=0;v<256;v++) L[k][v]=curve(sh(Math.pow(v/255,2)*(HEAD+FOOT)-FOOT+off[k]));
    for(let i=0;i<a.length;i+=4){ let R=L[0][a[i]], G=L[1][a[i+1]], B=L[2][a[i+2]]; const y=0.3*R+0.5*G+0.2*B;
      // (as the engine: what already has colour gets up to VB more of it, near-grey things none and only CS of the usual)
      const sp=Math.max(R,G,B)-Math.min(R,G,B), vs=(VB>0||CS!==1)&&sat>0?sat*(CS+(1+VB-CS)*Math.min(1,Math.max(0,(sp-VF)/(VT-VF)))):sat;
      let dR=vs*(R-y), dG=vs*(G-y), dB=vs*(B-y); const hi=Math.max(dR,dG,dB,1e-6), lo=Math.min(dR,dG,dB,-1e-6), f0=Math.max(0,Math.min(1e4,((D.TOP||1)-y)/hi,(y-0.006)/-lo)), fit=RS?f0/Math.pow(1+Math.pow(f0,RS),1/RS):Math.min(1,f0);
      R=y+fit*dR; G=y+fit*dG; B=y+fit*dB;
      if(clip&&Math.min(R,G,B)>=0.997){a[i]=255;a[i+1]=40;a[i+2]=40;} else if(clip&&Math.max(R,G,B)<=0.003){a[i]=40;a[i+1]=90;a[i+2]=255;}
      else { a[i]=R<=0?0:R>=1?255:Math.round(R*255); a[i+1]=G<=0?0:G>=1?255:Math.round(G*255); a[i+2]=B<=0?0:B>=1?255:Math.round(B*255); } }
  } else {
    const lut=new Float32Array(256); for(let v=0;v<256;v++) lut[v]=curve(Math.pow(v/255,2));
    for(let i=0;i<a.length;i+=4){ const y=lut[a[i]];
      if(clip&&y>=0.997){a[i]=255;a[i+1]=40;a[i+2]=40;} else if(clip&&y<=0.003){a[i]=40;a[i+1]=90;a[i+2]=255;}
      else { const q=y<=0?0:y>=1?255:Math.round(y*255); a[i]=a[i+1]=a[i+2]=q; } }
  }
  o.putImageData(im,0,0); return c;
}
function turned(src,tn,mirror){
  const sw=tn%2?src.height:src.width, sh=tn%2?src.width:src.height;
  cv.width=sw; cv.height=sh; const k=cv.getContext('2d'); k.save(); k.translate(sw/2,sh/2); k.rotate(tn*Math.PI/2); if(mirror) k.scale(-1,1);
  k.drawImage(src,-src.width/2,-src.height/2); k.restore();
}
const mates=p=>pics.filter(q=>q.scan===p.scan&&!q.skipped&&!q.full).sort((a,b)=>a.half-b.half);
// a diptych is made only of two halves that are both made: none when a half is skipped (here or by the converter)
const dipMade=p=>!p.full&&pics.filter(q=>q.scan===p.scan&&!q.full).length===2&&mates(p).length===2&&!mates(p).some(q=>get(q.id).skip);
// (the diptych view: a half-frame scan with both halves made and a diptych asked for; not while either half is
//  skipped, as no diptych is made then: View Pair greys and the half on screen is shown dimmed, "Skipped: ...")
const pairable=p=>!p.full&&mates(p).length===2&&dipOn(get(p.scan));
const canPair=p=>pairable(p)&&!mates(p).some(skippedNow);
// In Single, a set-aside frame that is selected (clicked in the list, S, an undo) is what is shown, so the
// line at the top, which then speaks of that frame, always describes the picture on screen.
const aimg=new Image();
function paintAside(){
  const a=asideOf(asideSel); if(!a) return;
  $('skipnote').style.display='none'; cv.style.display='';
  const src='/aside/'+U(a.scan)+'.jpg?v='+ver;
  if(aimg._src!==src){ aimg._src=src; aimg.onload=paint; aimg.src=src; return; }
  if(!aimg.complete||!aimg.naturalWidth) return;
  cv.width=aimg.naturalWidth; cv.height=aimg.naturalHeight; cv.getContext('2d').drawImage(aimg,0,0);
}
function paint(){
  geom=null;
  if(view!=='single') return;
  if(asideSel!==null&&asideOf(asideSel)) return paintAside();
  const p=pics[order[cur]]; if(!p||p.skipped) return;
  if(pair&&canPair(p)) return paintPair(p);
  if(!img.complete||!img.naturalWidth) return;
  const f=get(p.id), off=toned(p,f,img), W=off.width, H=off.height;
  // the stored picture has a margin all round; cut the crop out of it (after any small straighten)
  const sc=W/p.rw, M=p.m*sc, u=p.unit*sc, c=f.crop||[0,0,0,0], lim=-p.m/p.unit;
  let [t,r,b,l]=c.map(v=>Math.max(lim,v)*u);
  let x0=M+l, y0=M+t, cw=W-2*M-l-r, ch=H-2*M-t-b; if(cw<16||ch<16){x0=M;y0=M;cw=W-2*M;ch=H-2*M;}
  const full=ctx; mid.width=Math.round(full?W:cw); mid.height=Math.round(full?H:ch); const m=mid.getContext('2d');
  m.save(); if(!full) m.translate(-x0,-y0); m.translate(W/2,H/2); m.rotate((f.tilt||0)*Math.PI/180); m.drawImage(off,-W/2,-H/2); m.restore();
  if(full){ m.fillStyle='rgba(0,0,0,.55)'; m.fillRect(0,0,W,y0); m.fillRect(0,y0+ch,W,H-y0-ch); m.fillRect(0,y0,x0,ch); m.fillRect(x0+cw,y0,W-x0-cw,ch);
    m.strokeStyle='#d8ac2f'; m.lineWidth=2; m.strokeRect(x0,y0,cw,ch); }
  const tn=((autoT(p,f)+f.turn)%4+4)%4;
  turned(mid,tn,f.mirror);
  geom={id:p.id,u,tn,mirror:!!f.mirror,W,H,M,mw:mid.width,mh:mid.height,box:full?[x0,y0,cw,ch]:[0,0,mid.width,mid.height]};
}
function paintPair(p){                        // both halves as they sit on the film, turned as one piece
  const hs=mates(p), ims=hs.map(h=>{ if(!cache[h.id]||cache[h.id]._v!==ver){ const i=new Image(); i._v=ver; i.onload=()=>{ if(pair) paint(); }; i.src='/review/'+U(h.id)+'.jpg?v='+ver; cache[h.id]=i; } return cache[h.id]; });
  if(ims.some(i=>!i.complete||!i.naturalWidth)) return;
  const sf=get(p.scan), fs=hs.map(h=>get(h.id)), S=Math.min(...hs.map((h,i)=>ims[i].naturalWidth/h.rw));
  const R=hs.map((h,i)=>{ const c=fs[i].crop||[0,0,0,0], u=h.unit, lim=-h.m/h.unit, [t,r,b,l]=c.map(v=>Math.max(lim,v)*u);
    return {X0:h.box[0]+l, X1:h.box[1]-r, Y0:h.box[2]+t, Y1:h.box[3]-b}; });
  const Ya=Math.max(R[0].Y0,R[1].Y0), Yb=Math.min(R[0].Y1,R[1].Y1);
  const closed=sf.closed>0||(sf.closed===0&&(fixes['/options']||[]).includes('close-gap'));
  const gap=closed?0:Math.max(0,R[1].X0-R[0].X1);
  mid.width=Math.round((R[0].X1-R[0].X0+gap+R[1].X1-R[1].X0)*S); mid.height=Math.round((Yb-Ya)*S);
  const m=mid.getContext('2d'); m.fillStyle='#000'; m.fillRect(0,0,mid.width,mid.height);
  let dx=0;
  hs.forEach((h,i)=>{ const t=toned(h,fs[i],ims[i]), sc=t.width/h.rw, r=R[i];
    m.drawImage(t,(h.m+r.X0-h.box[0])*sc,(h.m+Ya-h.box[2])*sc,(r.X1-r.X0)*sc,(Yb-Ya)*sc,dx,0,(r.X1-r.X0)*S,mid.height);
    dx+=(r.X1-r.X0)*S+(i===0?gap*S:0); });
  const tn=hs.map((h,i)=>((autoT(h,fs[i])+fs[i].turn)%4+4)%4);
  const unit=tn[0]===tn[1]?tn[0]:(hs[0].conf>=hs[1].conf?tn[0]:tn[1]);
  turned(mid,(unit+(sf.turn||0))%4,false);
}

// ---- the crop, dragged with the mouse in Single (engine 61).  Each edge of the picture can be dragged in (trim)
// or out (show more), as far as the old keys went; while dragging, what is outside the crop is shown dimmed.
// The crop is kept as before: presses of a quarter of one per cent of the holder window, per side of the picture
// as it lies on the scan (top, right, bottom, left), so old settings files still read the same.
let geom=null, drag=null;
function cropOnScreen(){                       // the crop as it is on screen: {l,t,r,b} in page pixels
  if(!geom||cv.style.display==='none') return null;
  const R=cv.getBoundingClientRect(), k=R.width/cv.width, [bx,by,bw,bh]=geom.box, sw=cv.width, sh=cv.height;
  const pt=(x,y)=>{ x-=geom.mw/2; y-=geom.mh/2; if(geom.mirror) x=-x; for(let i=0;i<geom.tn;i++){ const t=x; x=-y; y=t; } return [R.left+(x+sw/2)*k, R.top+(y+sh/2)*k]; };
  const c=[pt(bx,by),pt(bx+bw,by),pt(bx,by+bh),pt(bx+bw,by+bh)], xs=c.map(v=>v[0]), ys=c.map(v=>v[1]);
  return {l:Math.min(...xs),r:Math.max(...xs),t:Math.min(...ys),b:Math.max(...ys),k};
}
function edgeAt(x,y){                          // which edge of the crop on screen is under the mouse: 0 top, 1 right, 2 bottom, 3 left
  const c=cropOnScreen(); if(!c) return -1; const g=10, inX=x>c.l-g&&x<c.r+g, inY=y>c.t-g&&y<c.b+g;
  const d=[inX?Math.abs(y-c.t):1e9, inY?Math.abs(x-c.r):1e9, inX?Math.abs(y-c.b):1e9, inY?Math.abs(x-c.l):1e9], m=Math.min(...d);
  return m<=g?d.indexOf(m):-1;
}
function cropDragOK(){ const p=pics[order[cur]]; return view==='single'&&D&&onMain()&&!anyOv()&&p&&!p.skipped&&asideSel===null&&!(pair&&canPair(p))&&geom&&geom.id===p.id; }
cv.addEventListener('mousemove',e=>{ if(drag) return; const s=cropDragOK()?edgeAt(e.clientX,e.clientY):-1; cv.style.cursor=s<0?'':s%2?'ew-resize':'ns-resize'; });
cv.addEventListener('mousedown',e=>{
  if(e.button!==0||!cropDragOK()) return; const side=edgeAt(e.clientX,e.clientY); if(side<0) return;
  e.preventDefault(); const p=pics[order[cur]], f=get(p.id);
  let s=((side-geom.tn)%4+4)%4; if(geom.mirror&&(s===1||s===3)) s=4-s;      // that edge as it lies on the scan (as the old ⇧-arrow keys)
  drag={id:p.id,side,s,x:e.clientX,y:e.clientY,c0:[...(f.crop||[0,0,0,0])],ctx0:ctx,tag:'crop'+(++tagN),k:null};
  ctx=true; paint(); info();                   // what is outside the crop, dimmed, while dragging
  drag.k=(cropOnScreen()||{k:1}).k;
});
addEventListener('mousemove',e=>{
  if(!drag) return; const p=pics[order[cur]]; if(!p||p.id!==drag.id||!geom){ endDrag(); return; }
  const dx=e.clientX-drag.x, dy=e.clientY-drag.y, inward=[dy,-dx,-dy,dx][drag.side];      // towards the middle: trim
  const presses=Math.round(inward/drag.k/geom.u), s=drag.s, c=[...drag.c0];
  const total=Math.floor(((s%2?geom.W:geom.H)-2*geom.M)/geom.u*0.8), lo=-Math.floor(p.m/p.unit);
  c[s]=Math.max(lo,Math.min(total-Math.max(0,c[(s+2)%4]),drag.c0[s]+presses));
  if(same(c,get(p.id).crop||[0,0,0,0])) return;
  snap(); fx(p.id).crop=c; tagNow=drag.tag; try{ after(); } finally{ tagNow=null; }
});
function endDrag(){ if(!drag) return; ctx=drag.ctx0; drag=null; paint(); info(); }
addEventListener('mouseup',endDrag);
addEventListener('blur',endDrag);

// ------------------------------------------------------------------ changing things

function colourToRoll(){                      // this picture's colour settings become the roll's, for every picture in it
  const p=pics[order[cur]]; if(!p||!p.colour) return; snap(); const f=fx(p.id), key=rk(p.roll), r={...rollFx(p.roll)};
  r.sat=r2((r.sat||0)+(f.sat||0)); r.warm=r2((r.warm||0)+(f.warm||0)); r.tint=r2((r.tint||0)+(f.tint||0)); fixes[key]=r; f.sat=0; f.warm=0; f.tint=0; after(); msg('Colour applied to roll '+p.roll);
}
// ---- undo.  Every change to the settings goes through snap() (before it) and save() (after it);
// what changed in between is one step: {setting: [as it was, as it is now]}.  A key held down
// adds to the step its first press made.  The steps are saved with the settings, so they are
// still there after an export, and after the folder is closed and opened again.
function snap(){ if(baseStr===null) baseStr=JSON.stringify(fixes); }
// (Make Diptych and Close the Gap open the diptych view: the step keeps whether it was on before and after, so undo
//  and redo put the view back as well)
let pairStep=null;
function commit(){
  if(baseStr===null) return; const was=JSON.parse(baseStr), d={}; baseStr=null;
  new Set([...Object.keys(was),...Object.keys(fixes)]).forEach(k=>{ if(!same(canon({[k]:was[k]})[k],canon({[k]:fixes[k]})[k])) d[k]=[was[k]===undefined?null:was[k], fixes[k]===undefined?null:JSON.parse(JSON.stringify(fixes[k]))]; });
  if(!Object.keys(d).length){ pairStep=null; return; }
  const last=hist.undo[hist.undo.length-1];
  if(tagNow&&last&&last.tag===tagNow){ Object.keys(d).forEach(k=>{ last.d[k]=[k in last.d?last.d[k][0]:d[k][0], d[k][1]]; }); }
  else { const e={tag:tagNow,d}; if(pairStep) e.pv=pairStep; hist.undo.push(e); if(hist.undo.length>300) hist.undo.shift(); }
  pairStep=null; hist.redo=[];
}
function change(fn){ snap(); targets().forEach(p=>fn(fx(p.id),p)); after(); }
function after(){ markStale(); paint(); info(); drawList(); drawGrid(); if(view==='rolls') drawRolls(); save(); dirty(); }
function doUndo(back){
  commit(); const from=back?hist.undo:hist.redo, to=back?hist.redo:hist.undo; if(!from.length){ msg(back?'Nothing to undo':'Nothing to redo'); return; }
  const e=from.pop();
  if(!e||typeof e.d!=='object'||!e.d||Object.values(e.d).some(v=>!Array.isArray(v)||v.length!==2)){ msg('That change could not be undone (its record was damaged), so it was skipped',1); save(); return; }
  e.tag=null;
  Object.keys(e.d).forEach(k=>{ const v=e.d[k][back?0:1]; if(v===null||v===undefined) delete fixes[k]; else fixes[k]=JSON.parse(JSON.stringify(v)); });
  to.push(e); D.fixes=fixes; baseStr=null;
  // go to what it changed, so the change is seen
  let where='';
  { const ks=Object.keys(e.d), rollOf=k=>{ const i=(D.rolls||[]).findIndex(r=>r.key===k); return i>=0?'roll '+(i+1):'a roll'; },
      what=ks.includes('/options')?'a folder option':ks.includes('/replace')?'Make the Picture Here After All':ks.some(k=>k.startsWith('/roll'))?rollOf(ks.find(k=>k.startsWith('/roll')))+' (type, film, note or colour)':
        ks.length===1?short(ks[0]):ks.length+' pictures';
    where=': '+what;
    // (a picture's change undone on Rolls, where it cannot be seen: the Grid, with that picture selected)
    if(view==='rolls'&&!rollTypeChanged()&&!ks.some(k=>k.startsWith('/'))&&order.some(pi=>ks.includes(pics[pi].id)||ks.includes(pics[pi].scan))) setView('grid');
    // (an undo or redo that changes a roll's type or film back from what was exported: those pictures are not the ones
    //  on screen, so it shows Rolls, where Review the pictures exports first; nothing is changed on pictures that would go)
    if(view!=='rolls'&&rollTypeChanged()){ setView('rolls'); where+=', on the Rolls screen: “'+ROLLGO_TYPE+'” exports first'; }
    if(view==='rolls'){ const k=ks.find(x=>x.startsWith('/roll')), i=k?(D.rolls||[]).findIndex(r=>r.key===k):-1;
      setTimeout(()=>{ const cards=document.querySelectorAll('#rollcards > div'), c=i>=0?cards[i]:ks.includes('/options')?$('rollcards').nextElementSibling:null;
        if(c){ c.scrollIntoView({block:'nearest'}); c.classList.add('flash'); setTimeout(()=>c.classList.remove('flash'),1200); } },60); } }
  if(view!=='rolls'){ const ks=Object.keys(e.d), a=ks.find(k=>asideOf(k)), i=order.findIndex(pi=>ks.includes(pics[pi].id)||ks.includes(pics[pi].scan));
    if(i>=0){ cur=i; sel.clear(); asideSel=null; if(view==='single') show(cur); else { drawGrid(); const c=$('t'+cur); if(c) c.scrollIntoView({block:'nearest'}); } }
    else if(a){ asideSel=a; }
    else if(ks.some(k=>k.startsWith('@'))&&!/Rolls screen/.test(where)) where+=', on the Rolls screen'; }
  if(Array.isArray(e.pv)) pair=!!e.pv[back?0:1];
  // (a pair skipped in the diptych view stays in it, shown dimmed, as S leaves it: only a picture with no pair leaves it)
  pair=pair&&!!pics[order[cur]]&&pairable(pics[order[cur]]);
  after(); msg((back?'Undone':'Redone')+where+(from.length?' ('+from.length+' more)':''));
}
// ---- back to automatic, for a picture, a roll or the whole folder; each is one step that undo takes back
// (a skip, a "checked", a set-aside frame made into a picture, and the way up it had when he checked it, are decisions,
//  not edits: every reset leaves them)
function decisionsOnly(k){ const v=fixes[k]; if(!v||k.startsWith('/')) return;
  const ok=v.ok?1:0, d={...NOFIX,crop:[0,0,0,0],skip:v.skip?1:0,ok,keep:v.keep?1:0,at:ok&&v.at>=0?v.at:-1};
  if(d.skip||d.ok||d.keep) fixes[k]=d; else delete fixes[k]; }
// (in the diptych view the pair's own quarter turns go back too, in the same undo step)
function resetPictures(){ const p=pics[order[cur]]; snap(); if(p&&view==='single'&&pair&&canPair(p)&&fixes[p.scan]&&fixes[p.scan].turn) fixes[p.scan].turn=0;
  change(f=>{f.turn=0;if(!f.ok)f.at=-1;f.density=0;f.contrast=0;f.mirror=0;f.crop=[0,0,0,0];f.tilt=0;f.sat=0;f.warm=0;f.tint=0;}); msg('Reset to automatic (⌘Z brings it back)'); }
function resetRoll(n){ snap(); pics.filter(p=>p.roll===n).forEach(p=>{ decisionsOnly(p.id); decisionsOnly(p.scan); }); delete fixes[rk(n)]; pair=false; after(); msg('Roll '+n+' is back to automatic; skips and checked marks stay'+typeBack()+' (⌘Z brings it back)'); }
// (the folder options, the For this folder box on Rolls, are left as they are)
function resetAll(){ snap(); Object.keys(fixes).forEach(k=>{ if(k==='/options'||k==='/replace') return; if(k.startsWith('/')||k.startsWith('@')) delete fixes[k]; else decisionsOnly(k); }); pair=false; after(); msg('Every picture and roll in this folder is back to automatic; skips and checked marks stay'+typeBack()+' (⌘Z brings it back)'); }
// (a reset that puts a roll's type or film back to automatic makes other pictures: Rolls, where Review exports first)
function typeBack(){ if(view==='rolls'||!rollTypeChanged()) return ''; setView('rolls'); return '. A roll\'s type changed: on Rolls, “'+ROLLGO_TYPE+'” exports first'; }
// Saving: a moment after each change, and at once when the folder is left, another is opened or the
// app quits.  Each save says which folder it is for; the engine refuses one for any other folder.
let unsaved=false, dataFails=0;
let saveSeq=Date.now()*1000, saving=Promise.resolve(true), lastSaved=0;
// (a key held down keeps pushing the wait back: it is saved at least once a second all the same)
function save(){ commit(); unsaved=true; try{ sendMenu(); }catch(e){} clearTimeout(saveT); if(Date.now()-lastSaved>1000){ lastSaved=Date.now(); saveNow(); } else saveT=setTimeout(saveNow,350); }
// one save at a time, in order; whoever waits for a save (quit, close, export) waits for the one in flight too
function saveNow(){ clearTimeout(saveT); saving=saving.then(doSave,doSave); return saving; }
async function doSave(){ if(!D||!unsaved) return true; commit(); lastSaved=Date.now(); const body=JSON.stringify({out:Dout,seq:++saveSeq,fixes,history:{undo:hist.undo,redo:hist.redo,at:JSON.stringify(canon(fixes))}}); unsaved=false;
  try{ const r=await fetch('/save',{method:'POST',body,keepalive:body.length<60000});
    if(r.ok) return true;
    // (never dropped quietly: whatever the engine answers, the change stays here, is saved with the next
    //  one, and the status line says it was not saved)
    unsaved=true; let why=''; try{ why=((await r.json())||{}).error||''; }catch(e){}
    // (but a folder that is no longer the open one: the change cannot be saved anywhere, and that is said plainly)
    if(r.status===409&&/not the one that is open/.test(why)){ unsaved=false; msg('That change was not saved: another folder was being opened.',1); return false; }
    msg('Could not save that change'+(why?' ('+why+')':'')+'. It is kept in the window and saved with your next change.',1); return false; }
  catch(e){ unsaved=true; return false; }      // the engine is away: kept here, and handed over when it is back
}
// reveal: a folder a click on the line shows in Finder (the output folder's own Trash folder)
// hold: the line stays until the next key or click (or 10 seconds), so it can be read (the Exported line, the first opening)
// said: the text already says what a click does
function msg(t,bad,reveal,hold,said){ const m=$('msg'); if(reveal&&!said) t+=' (click here to show it in Finder)';
  m.onclick=()=>{ msgClear(); if(reveal) native({cmd:'reveal',path:reveal}); };
  m.textContent=t; m.title=t; m._exp=false; m.style.color=bad?'var(--flag-soft)':''; m.style.cursor=reveal?'pointer':''; m._hold=!!hold&&!bad; m._at=Date.now();
  clearTimeout(m._t); m._t=setTimeout(msgClear,bad?(reveal?30000:12000):hold?10000:3000); }
function msgClear(){ const m=$('msg'); clearTimeout(m._t); m.textContent=''; m.title=''; m.style.cursor=''; m._hold=false; }
// (a line that is held goes at the next key or click anywhere but on the line itself)
// (not while a sheet is open: that key or click is for the sheet, e.g. Esc on the question about a file of his own)
addEventListener('keydown',()=>{ const m=$('msg'); if(m._hold&&!anyOv()&&Date.now()-m._at>300) msgClear(); },true);
addEventListener('mousedown',e=>{ const m=$('msg'); if(m._hold&&!anyOv()&&e.target!==m&&Date.now()-m._at>300) msgClear(); },true);
function ov(id,on){ $(id).style.display=on?'flex':'none'; }
const anyOv=()=>['help','report','zoom','busy','down','reset','about','mine'].some(i=>$(i).style.display==='flex');
async function exportAll(){ if(!D) return; await saveNow(); await post('/export'); poll(); }
function copySettings(){ if(Date.now()-lastCP<200) return; lastCP=Date.now(); const p=pics[order[cur]]; if(!p) return; const f=get(p.id); clipb={density:f.density,contrast:f.contrast,sat:f.sat||0,warm:f.warm||0,tint:f.tint||0}; msg('Copied settings'); }
// (colour goes only onto colour pictures: a black-and-white one takes the brightness and contrast)
function pasteSettings(){ if(Date.now()-lastCP<200) return; lastCP=Date.now(); if(clipb) change((f,q)=>{f.density=clipb.density;f.contrast=clipb.contrast; if(q.colour){ f.sat=clipb.sat;f.warm=clipb.warm;f.tint=clipb.tint; } }); }

// ------------------------------------------------------------------ buttons

$('openbtn').onclick=()=>{ native({cmd:'open'}); };
$('drop').onclick=e=>{ if(e.target.id==='drop') native({cmd:'open'}); };
if(!hasNative){ $('devopen').style.display='flex'; $('devgo').onclick=()=>post('/open',{paths:[$('devpath').value.trim()]}).then(poll); }
else document.documentElement.classList.add('native');
$('cancel').onclick=$('bcancel').onclick=()=>post('/cancel').then(poll);
$('getdng').onclick=()=>native({cmd:'url',url:st.adobe});
$('retry').onclick=()=>post('/export').then(poll);
$('dngback').onclick=$('back').onclick=async()=>{ await window.appFlush(); clip=false; ctx=false; pair=false; await post('/close'); poll(); };
document.querySelectorAll('#tabs button').forEach(b=>b.onclick=()=>goView(b.dataset.v));
$('order').onclick=()=>{ redFirst=!redFirst; sel.clear(); setOrder(); if(view==='single') show(cur); else { drawGrid(); info(); } };
$('bkeys').onclick=()=>ov('help',1);
// Reset: the picture (or the selected ones) and its roll; on Rolls, each roll.  Everything in the folder is offered
// apart, smaller, with what it takes in; Cancel (or Esc, or a click outside) leaves everything as it is.
$('breset').onclick=()=>{ if(!D) return; const p=pics[order[cur]], onRolls=view==='rolls'||!p, n=onRolls?0:targets().length;
  $('rpic').textContent=n>1?'These '+n+' pictures':'This picture'; $('rroll').textContent=p?'Roll '+p.roll:'This roll';
  $('rpic').style.display=$('rroll').style.display=onRolls?'none':'';
  $('rrolls').innerHTML=onRolls?(D.rolls||[]).map(r=>'<button data-n="'+(+r.n)+'">Roll '+(+r.n)+'</button>').join(''):'';
  $('rrolls').querySelectorAll('button').forEach(b=>b.onclick=()=>{ ov('reset',0); resetRoll(+b.dataset.n); });
  const nr=(D.rolls||[]).length;
  $('rall').textContent='Everything: '+pics.filter(q=>!q.skipped).length+' pictures, '+nr+' roll'+(nr===1?'':'s');
  ov('reset',1); };
$('rpic').onclick=()=>{ ov('reset',0); resetPictures(); };
$('rroll').onclick=()=>{ ov('reset',0); const p=pics[order[cur]]; if(p) resetRoll(p.roll); };
$('rall').onclick=()=>{ ov('reset',0); resetAll(); };
$('rcancel').onclick=()=>ov('reset',0);
// The Report: titled with the folder, its folder named short, and without the file's own mark (that stays in report.txt)
$('breport').onclick=()=>{ if(!D) return; let t=D.report||''; if(D.prefix&&D.prefix.length>1) t=t.split('\n').map((ln,i)=>i?ln.split(D.prefix).join(''):ln).join('\n');
  t=t.split('\n').filter(ln=>!/^(412 Film|Film Converter) FC\d+:/.test(ln)).join('\n').replace(/\s+$/,'');
  t=t.replace(/^(.*?)\s+->\s+(.*)$/m,(m,a,b)=>a+', in '+where(b));
  // the file is as of the last export; what is still to check is said as it is now, in place of its list
  const ls=t.split('\n'), at=ls.findIndex(ln=>/^Please check (these \d+|this one)/.test(ln));
  if(at>=0){ let e=at+1; while(e<ls.length&&/^  \S/.test(ls[e])) e++;
    const N=pics.filter(isFlagged).length, red=order.map(k=>pics[k]).filter(isRed);
    ls.splice(at,e-at,...(red.length?[(red.length===1?'Still to check: 1':'Still to check: '+red.length)+' of '+N+' (outlined in red):'].concat(red.map(q=>'  '+short(q.id)+': '+checkWords(q).lead.replace(/^./,c=>c.toLowerCase()))):
      ['Every picture flagged for checking has been checked'+(N?' ('+N+')':'')+'.'])); t=ls.join('\n'); }
  const w=D.report_when?new Date(D.report_when*1000):null, hm=w?String(w.getHours()).padStart(2,'0')+':'+String(w.getMinutes()).padStart(2,'0'):'';
  $('rept').textContent='Report: '+folderName(st.folder)+(w?', as of the last export ('+friendlyWhen(w.getFullYear()+'-'+String(w.getMonth()+1).padStart(2,'0')+'-'+String(w.getDate()).padStart(2,'0')+' '+hm)+')':'');
  $('reptext').textContent=t; ov('report',1); };
$('repclose').onclick=e=>{ e.stopPropagation(); ov('report',0); };
$('breveal').onclick=()=>native({cmd:'reveal',path:st.out});
$('bexport').onclick=exportAll;
$('toroll').onclick=colourToRoll;
// (the view only changes once the export has finished: cancelling it leaves the Rolls screen as it is)
// Rolls: the button goes to the Grid; only a change of a roll's type or film is exported first (it makes other pictures)
$('rollgo').onclick=()=>goView('grid');
['help','report','zoom','reset','about','mine'].forEach(i=>$(i).onclick=()=>ov(i,0));
$('zclose').onclick=e=>{ e.stopPropagation(); ov('zoom',0); };
// files of his own in the way of pictures: asked once per export, three answers
// (every file is listed (the list scrolls), and the answer is about exactly the files shown, each with
//  the content it had when it was listed: nothing that was not shown is affected)
let mineKey='', mineShown=[];
function askMine(){ const b=(st&&st.blocked)||[]; const k=st.out+'|'+st.runs+'|'+b.length; if(!b.length||k===mineKey||st.phase!=='ready') return; mineKey=k;
  const hs=(st&&st.blocked_h)||{}; mineShown=b.map(n=>({name:n,h:hs[n]||''}));
  const one=b.length===1;
  $('minet').textContent=one?'A file of your own is where a picture should go':b.length+' files of your own are where pictures should go';
  $('mineb').textContent=one?'412 Film did not write this file, or it was changed after 412 Film wrote it, so it has left it alone:':
    '412 Film did not write these files, or they were changed after 412 Film wrote them, so it has left them alone:';
  $('minel').textContent=b.join('\n'); ov('mine',1); }
// "decide later" (Esc, a click outside): the line after the export says again what was not made, and stays
function mineLater(){ ov('mine',0); if(st&&st.summary&&D) sayExported(); }
// (the answer changes what is marked at once: Keep mine takes "not made" off and lets the Export All lamp go out;
//  the pictures themselves are only loaded again after an export, so the marks are redrawn here)
// (and the line that said what was not made is put right at once: Keep mine counts it as his file; the other answers export)
const decide=c=>{ ov('mine',0); post('/decide',{choice:c,files:mineShown}).then(poll).then(()=>{ if(globalThis.redrawMarks) redrawMarks(); if(globalThis.lineAfterDecide) lineAfterDecide(c); }); };
function lineAfterDecide(c){ const m=$('msg'); if(m._exp&&m.textContent){ if(c==='keep'&&st&&st.summary) sayExported(); else msgClear(); } }
function redrawMarks(){ if(!D) return; dirty(); drawList(); drawGrid(); info(); }
$('mine').onclick=mineLater;
$('mkeep').onclick=()=>decide('keep'); $('mrepl').onclick=()=>decide('replace'); $('mbeside').onclick=()=>decide('beside');
$('reptext').parentNode.onclick=e=>e.stopPropagation();      // words in the Report can be selected without closing it

// ------------------------------------------------------------------ keys

function inField(t){ t=t||document.activeElement; return !!t&&['INPUT','SELECT','TEXTAREA'].includes(t.tagName); }
addEventListener('keydown',e=>{
  if(e.target&&e.target.tagName==='SELECT'){ e.target.blur(); e.preventDefault(); }     // (keys must never change a roll's type by its first letter)
  if(inField(e.target)&&e.target.tagName!=='SELECT'){ if(e.key==='Escape'||e.key==='Enter') e.target.blur(); return; }
  const k=e.key, K=k.length===1?k.toLowerCase():k, cmd=e.metaKey, alt=e.altKey, sh=e.shiftKey, rep=e.repeat, arrow=k.startsWith('Arrow');
  if(e.ctrlKey) return;                        // nothing here uses Control
  if(opening){ e.preventDefault(); return; }    // (another folder is being opened: see appOpen)
  // (the question about files of his own is only put away with Esc or a click outside it: Return or Space must not answer it by accident)
  if($('mine').style.display==='flex'){ if(k==='Escape'&&!rep) mineLater(); if(!cmd) e.preventDefault(); return; }
  if(anyOv()){ if(!cmd&&!alt&&(k==='Escape'||k==='?'||k==='Enter'||k===' ')){ if(!rep) ['help','report','zoom','reset','about','mine'].forEach(i=>ov(i,0)); e.preventDefault(); } return; }
  if(!D||!onMain()) return;
  const p=pics[order[cur]];
  const single=view==='single', grid=view==='grid', rolls=view==='rolls';
  let used=true;
  // a key held down is one undo step: its repeats carry the tag its first press was given
  if(!rep) heldTag='key'+(++tagN); tagNow=heldTag;
  try{ used=keyDo(e,k,K,cmd,alt,sh,rep,arrow,p,single,grid,rolls); } finally{ tagNow=null; }
  if(used) e.preventDefault();
});
// a picture whose only doubt is which way up has been looked at once he turns it: the turn marks it checked,
// in the same undo step.  Any other doubt (a guessed split, the holder window, ...) still wants Return.
const ONLY_WAY_UP='not sure which way up';
function turnBy(p,k){                          // a quarter turn right (→) or left (←): the picture, or in the diptych view the pair
  if(pair&&canPair(p)){ snap(); const f=fx(p.scan); f.turn=((f.turn||0)+(k==='ArrowRight'?1:3))%4; mates(p).forEach(h=>{ if(h.check===ONLY_WAY_UP&&!get(h.id).ok){ const g=fx(h.id); pin(g,h); g.ok=1; } }); after(); }
  else change((f,q)=>{ pin(f,q); f.turn=(f.turn+(k==='ArrowRight'?1:3))%4; if(q.check===ONLY_WAY_UP) f.ok=1; });
}
// ---- keys (engine 61): the arrows do nearly everything; a modifier says what.
// Single: ← ↑ previous, → ↓ next.  Grid: the plain arrows move around.  In both, on the picture you are on and
// any selected: ⌘↑ ⌘↓ brightness, ⌥↑ ⌥↓ contrast, ⇧← ⇧→ turn; colour only: ⌘← ⌘→ cooler / warmer,
// ⌥← ⌥→ green / magenta, ⇧↑ ⇧↓ saturation.  What used to have a letter key is in the Picture menu (menuDo).
function keyDo(e,k,K,cmd,alt,sh,rep,arrow,p,single,grid,rolls){
  const once=fn=>{ if(!rep) fn(); }, mods=(cmd?1:0)+(alt?1:0)+(sh?1:0);   // (switches: a held key must not flip them back and forth)
  const fwd=k==='ArrowRight'||k==='ArrowDown';
  if(cmd&&!arrow){
    if(K==='z'&&!alt){ if(!rep) doUndo(!sh); return true; }
    if(K==='y'&&!alt&&!sh){ if(!rep) doUndo(false); return true; }
    if(K==='e'&&!alt&&!sh){ once(exportAll); return true; }               // (the Picture menu's Export All, if the menu passes it on)
    if(rolls||!p||alt||sh||asideSel!==null) return false;
    if(K==='c'){ copySettings(); return true; }
    if(K==='v'){ pasteSettings(); return true; }
    if(k==='Backspace'){ once(resetPictures); return true; }               // (the Picture menu's Reset Picture)
    if(K==='['||K===']'){                     // (the Picture menu's Straighten Left / Right; not in the diptych view)
      if(single&&pair&&canPair(p)){ if(!rep) msg('Straighten works on single pictures: leave the pair view first (Picture › View Pair)'); return true; }
      menuDo(K==='['?'straighten-left':'straighten-right'); return true; }
    return false;
  }
  if(k===' '&&!mods){ once(()=>goView(single?'grid':grid?'single':'grid')); return true; }
  if(k==='?'){ once(()=>ov('help',1)); return true; }
  if(rolls) return false;
  if(asideSel!==null){                         // a set-aside frame is selected: S, moving on, Esc
    if(K==='s'&&!mods){ once(()=>toggleKeep(asideSel)); return true; }
    if(arrow&&!mods){ if(grid) gridMove(k); else asideStep(fwd?1:-1); return true; }
    if(k==='Escape'){ asideSel=null; if(single) show(cur); else { drawGrid(); drawList(); info(); } return true; }
    return false;
  }
  // (no pictures at all: the arrows go to the frames set aside)
  if(!p){ if(arrow&&!mods&&D&&(D.aside||[]).length){ if(grid) gridMove(k); else showNone(); return true; } return false; }
  if(arrow){
    if(!mods){ if(grid) gridMove(k); else { sel.clear(); show(stepFrom(fwd?1:-1)); } return true; }
    if(mods>1) return false;                   // one modifier at a time
    const vert=k==='ArrowUp'||k==='ArrowDown', d=(k==='ArrowUp'||k==='ArrowRight')?1:-1;
    if(cmd&&vert){ change(f=>f.density=r2(f.density-0.05*d)); gridSay('Brightness'); return true; }      // ⌘↑ brighter (less density)
    if(alt&&vert){ change(f=>f.contrast=r2(f.contrast+0.05*d)); gridSay('Contrast'); return true; }
    if(sh&&!vert){ turnBy(p,k); return true; }
    // the rest is colour: on the picture(s) it acts on that are colour; with none, the line says so
    if(!targets().some(q=>q.colour)){ if(!rep) msg('Black-and-white: no colour to change'); return true; }
    if(cmd){ change((f,q)=>{ if(q.colour) f.warm=r2((f.warm||0)+0.01*d); }); gridSay('Warmth'); }       // ⌘← cooler, ⌘→ warmer
    else if(alt){ change((f,q)=>{ if(q.colour) f.tint=r2((f.tint||0)+0.01*d); }); gridSay('Tint'); }  // ⌥← green, ⌥→ magenta
    else { change((f,q)=>{ if(q.colour) f.sat=r2((f.sat||0)+0.05*d); }); gridSay('Saturation'); }    // ⇧↑ more, ⇧↓ less saturation
    return true;
  }
  if(k==='Enter'&&!cmd&&!alt){
    if(grid){ if(!sh) once(()=>setView('single')); return !sh; }
    // (in the diptych view both halves are on screen: OK marks each flagged half, and moves on to the next scan)
    once(()=>{ const hs=single&&pair&&canPair(p)?mates(p):[p], todo=sh?[]:hs.filter(h=>h.check&&!get(h.id).ok);
      if(todo.length){ snap(); todo.forEach(h=>{ const f=fx(h.id); f.ok=1; pin(f,h); }); save(); dirty(); } sel.clear(); show(stepFrom(sh?-1:1)); });
    return true;
  }
  // (in the diptych view S skips the pair, both halves; pressed again there it brings both back)
  // (its undo step keeps the diptych view, as Make Diptych's does: undo and redo come back to it)
  if(K==='s'&&!mods){ once(()=>{ const on=!get(p.id).skip, ts=targets(), pv=single&&pair&&pairable(p); if(pv) mates(p).forEach(h=>{ if(!ts.includes(h)) ts.push(h); });
    snap(); ts.forEach(q=>fx(q.id).skip=on?1:0); if(pv) pairStep=[true,true]; after(); }); return true; }
  return false;
}
// The next / previous picture in Single.  In the diptych view the other half of the pair on screen is not a next
// picture (it is already on screen): the step goes past it to the next or previous scan.
function stepFrom(dir){
  const p=pics[order[cur]]; let j=cur+dir;
  if(p&&view==='single'&&pair&&canPair(p)) while(j>=0&&j<order.length&&pics[order[j]].scan===p.scan&&!pics[order[j]].full) j+=dir;
  if(j<0||j>=order.length) return Math.max(0,Math.min(order.length-1,cur+dir));
  // (in the diptych view a pair is always come to on its first half, from either side, so that ← after → is back where it was)
  const q=pics[order[j]]; if(view==='single'&&pair&&q&&canPair(q)){ const ks=order.map((x,i)=>i).filter(i=>pics[order[i]].scan===q.scan&&!pics[order[i]].full); j=Math.min(...ks); }
  return j;
}
// In the Grid the thumbnails do not show brightness, contrast or colour (only Single does, and the pictures after
// Export All), so a change made there is said on the status line: what, its value on the picture you are on, on how many.
function gridSay(what){
  if(view!=='grid') return; const ts=targets(), p=pics[order[cur]]; if(!p) return; const f=get(p.id), r=p.colour?rollFx(p.roll):{}, sg=v=>(v>0?'+':'')+r2(v).toFixed(2);
  const v={Brightness:-f.density||0,Contrast:f.contrast||0,Straighten:f.tilt||0,Warmth:(r.warm||0)+(f.warm||0),Tint:(r.tint||0)+(f.tint||0),Saturation:(r.sat||0)+(f.sat||0)}[what];
  const n=['Brightness','Contrast','Straighten'].includes(what)?ts.length:ts.filter(q=>q.colour).length;
  msg(what+' '+(what==='Straighten'?(v>0?'+':'')+(+v).toFixed(1)+'°':sg(v))+' on '+(n===1?short(p.id):n+' pictures')+' · seen in Single, and in the pictures after Export All');
}
// in Single, from a set-aside frame: the arrows step along the frames listed after the pictures; before the first, the last picture
function asideStep(dir){
  const A=D.aside||[], j=A.findIndex(a=>a.id===asideSel)+dir;
  if(j<0){ if(!order.length) return; sel.clear(); show(order.length-1); } else if(j<A.length){ asideSel=A[j].id; paint(); drawList(); info(); }
}

// ---- the Picture menu (shell/main.swift).  The page says which items apply just now (the others are greyed,
// so none can beep), and which are ticked; choosing one calls appMenu(name).
const gapClosed=sf=>sf.closed>0||(sf.closed===0&&(fixes['/options']||[]).includes('close-gap'));   // (the scan's own say, else the folder option)
// (File > Open… is grey while an export runs: opening another folder would stop it.  Edit > Undo / Redo only when
//  there is something to undo or redo: a text field's own, or a change to the pictures)
const exporting=()=>!!(st&&st.phase==='working'&&D&&(st.runs>0||st.has_results));
function menuState(){
  const on=[], chk=[];
  if(!exporting()) on.push('open');
  if(inField()) on.push('undo','redo');
  else if(D&&onMain()&&!anyOv()){ if(hist.undo.length||baseStr!==null) on.push('undo'); if(hist.redo.length) on.push('redo'); }
  if(anyOv()) return {on,chk};
  on.push('keys');                             // (Help > Keys: wherever the window is)
  if(!D||!onMain()) return {on,chk};
  on.push('export','close','reveal','report');  // (File menu)
  const p=pics[order[cur]], single=view==='single';
  if(view==='rolls'||!p||asideSel!==null) return {on,chk};
  // (the diptych view shows both halves as they sit on the film, without their own straighten or mirror: those are
  //  greyed there, and so is Zoom to 100%, which shows one picture)
  const pv=single&&pair&&canPair(p);
  on.push('order','reset'); if(!pv) on.push('mirror','straighten-left','straighten-right'); if(redFirst) chk.push('order'); if(get(p.id).mirror) chk.push('mirror');
  if(!p.skipped&&!pv) on.push('zoom');
  if(p.colour) on.push('toroll');
  if(keptIds().has(p.id)&&!withdrawn(p.id)&&((st&&st.kept_h)||{})[keptFileOf(p.id)]) on.push('replace');
  if(!p.full){ const sf=get(p.scan); on.push('diptych','gap');
    if(dipOn(sf)) chk.push('diptych'); if(gapClosed(sf)) chk.push('gap');
    if(single&&canPair(p)){ on.push('pair'); if(pair) chk.push('pair'); } }
  if(single&&!p.skipped){ on.push('clip','outside'); if(clip) chk.push('clip'); if(ctx) chk.push('outside'); }
  return {on,chk};
}
let menuSent='';
function sendMenu(){ const s=JSON.stringify(menuState()); if(s===menuSent) return; menuSent=s; native(Object.assign({cmd:'menu'},JSON.parse(s))); }
setInterval(sendMenu,400);
// (and at once when a text field gets or loses the cursor: Undo and Redo are then the field's own)
addEventListener('focusin',()=>sendMenu()); addEventListener('focusout',()=>setTimeout(sendMenu,0));
function menuDo(n){
  if(opening&&n!=='open') return false;
  const ms=menuState(); if(!ms.on.includes(n)) return false;
  const p=pics[order[cur]];
  // (straightening a few tenths, ⌘] ⌘] ⌘], is one undo step; so is a key held down)
  const tilt=n.startsWith('straighten'); tagNow=tilt&&Date.now()-lastTilt<800&&tiltTag?tiltTag:tagNow||'menu'+(++tagN); if(tilt){ tiltTag=tagNow; lastTilt=Date.now(); }
  try{
    if(n==='open') native({cmd:'open'});
    else if(n==='export') exportAll();
    else if(n==='close') $('back').onclick();
    else if(n==='reveal') $('breveal').onclick();
    else if(n==='report') $('breport').onclick();
    else if(n==='keys') ov('help',1);
    else if(n==='order') $('order').onclick();
    else if(n==='reset') resetPictures();
    else if(n==='mirror') change(f=>f.mirror=f.mirror?0:1);
    else if(n==='straighten-left'){ change(f=>f.tilt=Math.max(-10,r2((f.tilt||0)-0.1))); gridSay('Straighten'); }     // anticlockwise
    else if(n==='straighten-right'){ change(f=>f.tilt=Math.min(10,r2((f.tilt||0)+0.1))); gridSay('Straighten'); }
    else if(n==='zoom') zoomOpen(p);
    else if(n==='toroll') colourToRoll();
    else if(n==='replace') replaceAfterAll(p);
    // Make Diptych: ticked while a diptych is made for the scan, by its own say or the folder option; chosen while ticked
    // it is taken off (with the folder option on, this scan then says "not for this scan": -1), as Close the Gap
    else if(n==='diptych'){ snap(); const on=!dipOn(get(p.scan)), all=dipAll(); [...new Set(targets().filter(q=>!q.full).map(q=>q.scan))].forEach(s=>fx(s).diptych=on?1:all?-1:0); const was=pair; pair=view==='single'&&on&&canPair(p); pairStep=[was,pair]; after(); }
    // Close the Gap: closes it, or (ticked) opens it again, whether it was closed for this scan or by the folder option
    // (then this scan says "open": -1; its own closing is taken back: 0)
    else if(n==='gap'){ snap(); const on=!gapClosed(get(p.scan)), all=(fixes['/options']||[]).includes('close-gap');
      [...new Set(targets().filter(q=>!q.full).map(q=>q.scan))].forEach(s=>{ fx(s).closed=on?1:all?-1:0; if(on) fx(s).diptych=1; });
      // (closing the gap makes a diptych: it is shown, in the diptych view)
      const was=pair; if(on&&view==='single'&&canPair(p)) pair=true; pairStep=[was,pair]; after(); }
    else if(n==='pair'){ pair=!pair; paint(); info(); }
    else if(n==='clip'){ clip=!clip; paint(); info(); }
    else if(n==='outside'){ ctx=!ctx; paint(); info(); }
  } finally{ tagNow=null; }
  sendMenu(); return true;
}
let lastTilt=0, tiltTag=null;
window.appMenu=n=>menuDo(n);
// The 100% view: the picture made from its scan with the settings as they are now, the way Export All will make it
// (the engine does it, a few seconds).  When it cannot be (the roll's type or film changed since the last export), the
// exported file is shown and the line above it says so.
let zoomSeq=0;
async function zoomOpen(p){
  if(!p) return; const seq=++zoomSeq, z=$('zimg'), cap=$('zcap');
  // (the picture's address is kept for as long as it is shown: WebKit may decode it again, scrolled or under memory pressure)
  if(z._url){ URL.revokeObjectURL(z._url); z._url=null; } z.removeAttribute('src'); z.style.display='none'; cap.textContent='Making '+short(p.id)+' at 100% with your settings now…'; ov('zoom',1);
  let r=null; try{ r=await fetch('/zoom',{method:'POST',body:JSON.stringify({id:p.id,fixes})}); }catch(e){}
  if(seq!==zoomSeq||$('zoom').style.display!=='flex') return;
  if(!r||!r.ok){ cap.textContent='The 100% view could not be made just now. Export All, then try again · Esc closes'; return; }
  const why=r.headers.get('X-FC-Zoom')||'', u=URL.createObjectURL(await r.blob());
  if(seq!==zoomSeq){ URL.revokeObjectURL(u); return; }
  // (one pixel of the picture to one pixel of the screen: on a Retina screen a CSS pixel is two)
  z._url=u; z.onload=()=>{ z.style.width=(z.naturalWidth/(window.devicePixelRatio||1))+'px'; z.style.height='auto'; const zp=z.parentNode; zp.scrollLeft=Math.max(0,(zp.scrollWidth-zp.clientWidth)/2); zp.scrollTop=Math.max(0,(zp.scrollHeight-zp.clientHeight)/2); };   // (centred, not at its top left)
  z.src=u; z.style.display='';
  cap.textContent=!why?short(p.id)+' at 100%, as Export All will make it · Esc closes':
    'Last exported version'+(why==='exported-roll'?' (the roll’s type or film has changed since)':'')+': Export All to see your changes · Esc closes';
  z.dataset.why=why||'now';
}
window.appMenuState=()=>JSON.stringify(menuState());
// ⌘C / ⌘V may arrive as menu commands instead of keys
['beforecopy','beforecut','beforepaste'].forEach(t=>document.addEventListener(t,e=>{ if(!inField(e.target)) e.preventDefault(); }));
document.addEventListener('cut',e=>{ if(!inField(e.target)) e.preventDefault(); });       // nothing here can be cut
document.addEventListener('copy',e=>{ if(String(getSelection()||'')) return;      // selected words (the Report) are copied as words
  if(D&&!inField()&&!anyOv()&&view!=='rolls'&&onMain()) copySettings();
  if(!inField(e.target)) e.preventDefault(); });     // (always answered here: nothing is left for the browser's own command)
document.addEventListener('paste',e=>{ if(D&&!inField()&&!anyOv()&&view!=='rolls'&&onMain()) pasteSettings(); if(!inField(e.target)) e.preventDefault(); });
addEventListener('pagehide',()=>{ saveNow(); });   // nothing typed in the last moment is lost
addEventListener('resize',()=>{ if(view==='single') paint(); if(view==='rolls') document.querySelectorAll('#rollcards .strip').forEach(fitStrip); reportDrag(); });
addEventListener('contextmenu',e=>{ if(!inField(e.target)) e.preventDefault(); });     // no browser menu in an app window
window.appAbout=v=>{ $('aboutv').textContent=v?'Version '+v:''; $('aboutu').textContent=''; ov('about',1); };
// Check for Updates: 412 Updater's window does the looking.  When it is not on this Mac the app says so, once, plainly.
const NOUPDATER='412 Updater is not on this Mac. Nothing is going to check.';
window.appNoUpdater=()=>{ if($('about').style.display==='flex') $('aboutu').textContent=NOUPDATER; else msg(NOUPDATER); };
$('aboutupd').onclick=e=>{ e.stopPropagation(); native({cmd:'updates'}); };
addEventListener('dragover',e=>e.preventDefault()); addEventListener('drop',e=>e.preventDefault());
native({cmd:'ready'});
poll();
